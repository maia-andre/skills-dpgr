---
name: revisar-testes
description: Audita testes do LicitaDocs contra a rubrica do playbook (docs/security/suite de testes v2.md) para garantir que PEGAM bugs, não que só ficam verdes. Use ao revisar um arquivo de teste, um PR de testes, ou periodicamente a suíte — especialmente após o histórico de testes rasos (casos João / versão+IDOR / workflow rebelde). Classifica cada teste como PROFUNDO ou RASO, com file:line e o assert que falta.
---

# Revisar testes (LicitaDocs)

Objetivo: encontrar **testes rasos** — os que ficam verdes sem provar o que importa — e propor a
correção. A doutrina completa está em `docs/security/suite de testes v2.md`; esta skill a aplica.

## Escopo
- Sem argumento → audite a suíte inteira (`tests/`).
- Com um caminho (ex.: `tests/integration/test_x.py`) → audite só esse arquivo.

## Procedimento
1. Leia o playbook (`docs/security/suite de testes v2.md`), em especial §2 (regra de ouro), §3
   (princípios), §4 (anti-padrões) e §5 (matriz "o que afirmar").
2. Para cada teste no escopo, leia o corpo e classifique:
   - **PROFUNDO** — afirma o resultado observável pelo usuário pelo caminho real (view/HTTP/banco);
     falharia se o comportamento que importa quebrasse.
   - **RASO** — cai em algum anti-padrão: só `status_code`/string sem checar efeito; exercita o
     domínio isolado quando o bug mora na integração; mocka o que testa; sem teste negativo de
     autorização numa view que recebe id; asserção tautológica.
3. Para cada RASO, identifique o **efeito não-afirmado** e escreva o **assert que falta** (concreto,
   pronto para colar), seguindo a matriz §5.
4. Cheque cobertura por gatilho:
   - Toda view que recebe `tr_id`/`id` tem teste **negativo** de autorização? (senão → achado)
   - Todo bug fix recente tem um teste que **falharia sem o fix**?
   - Ações críticas (salvar/enviar/aprovar/reprovar/assinar/reset-senha) afirmam o efeito +
     `HistoricoVersao`/`AuditoriaLog` quando aplicável?
5. NÃO altere código de produção para "fazer passar". Se um assert profundo **falhar**, isso é um
   provável **bug** — reporte como achado separado (não silencie ajustando o teste para o errado).

## Saída (formato)
Uma tabela: `arquivo:linha | teste | classificação | efeito não-afirmado | assert sugerido`.
Depois, uma lista priorizada dos RASOS mais graves (autorização > integridade > persistência >
cosmético) e quais viram **teste negativo** novo.

## Lembre
Verde ≠ correto. Um teste só vale se **falharia** quando o que importa quebra. Se for aplicar as
correções, faça em TDD (mostre o red antes) e mantenha a suíte verde ao final.
