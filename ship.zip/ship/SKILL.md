---
name: ship
description: Fecha um incremento APROVADO pelo /review-and-security — roda a suíte uma última vez, marca o incremento como concluído no docs/plan.md, atualiza o CHANGELOG.md e faz o commit amarrado ao INC-XX e aos REQ-XX. Recusa-se a fechar sem review APROVADO. Usar quando o usuário executar /ship ou pedir para fechar/commitar o incremento.
---

# /ship — Fechamento do incremento

Você fecha a iteração do ciclo: registra o incremento como concluído e deixa o histórico limpo. **Você não altera código de produção nem testes** — se algo estiver quebrado, o lugar dele é no `/build`.

## Fase 1 — Portão de entrada

1. Leia `docs/review-report.md`. Só prossiga se o VEREDITO for **APROVADO** e referente ao incremento atual (confira INC-XX e data contra o `docs/build-report.md`). Sem review, ou com REPROVADO, **pare** e oriente: `/review-and-security` primeiro.
2. Se o working tree está idêntico ao estado em que o `/review-and-security` rodou a suíte verde (o caso normal — o ship não toca código), **cite a rodada do review em vez de re-executar**. Re-rode a suíte (com `-n auto` se houver pytest-xdist) apenas se algo mudou desde o review. Qualquer falha → **pare** e oriente a rodar `/build`; não feche incremento com suíte vermelha.
3. Retomada: se o `docs/plan.md` já marca o incremento como `concluído` mas o commit correspondente da Fase 3 não existe, um fechamento anterior foi interrompido — complete as Fases 2 e 3 a partir do que falta, sem duplicar o que já foi feito.

## Fase 2 — Atualizar o estado do ciclo

1. Em `docs/plan.md`: marque o incremento `Status: concluído` e atualize a linha `Progresso: X/N incrementos concluídos`.
2. Atualize `CHANGELOG.md` (crie se não existir), no topo:

```markdown
## INC-XX — <nome do incremento> (<data>)
- REQ-01: <o que passou a existir, em 1 linha voltada ao usuário>
- REQ-02: ...
```

3. Se o `CLAUDE.md` do projeto documentar comandos ou estrutura que este incremento mudou (porta nova, script novo, entidade nova), atualize a seção correspondente — mudança mínima, nada de reescrever o arquivo.

## Fase 3 — Commit

1. Se o projeto ainda não é um repositório git, rode `git init` e crie um `.gitignore` adequado à stack antes do primeiro commit.
2. Confira o `git status` e o diff: só entra no commit o que pertence ao incremento (código, testes, docs do ciclo). Segredos, `.env`, artefatos de build e arquivos temporários ficam de fora — se aparecerem no status, adicione ao `.gitignore`.
3. Faça o commit com mensagem amarrada ao contrato:

```
INC-XX: <nome do incremento>

Atende REQ-01, REQ-02; cobre CE-01. Review APROVADO em <data>.
```

4. **Push:** se o trabalho está numa **branch de feature** (qualquer coisa que não seja a branch principal nem a de homologação), faça `git push` dela ao fechar o incremento — trabalho commitado só na máquina do usuário é trabalho invisível para o time e sujeito a perda. **NUNCA** faça push direto na branch principal (`main`/`master`) nem na de homologação: promoção entre elas é ato do usuário (PR/merge na interface). Se o push for bloqueado por permissão, **avise no fechamento** em vez de seguir em silêncio.

## Fase 4 — Encerramento da iteração

Informe ao usuário, em poucas linhas: o que foi fechado, o hash do commit e o progresso (X/N).

- Se ainda há incremento `pendente` no `docs/plan.md`: anuncie qual é o próximo (INC-XX — nome) e que o passo seguinte é `/build`. Num loop autônomo, é o sinal para a próxima iteração começar.
- Se **não** há mais pendentes: declare o backlog concluído, confira a `Definição de concluído` da spec item a item e reporte o resultado. Se estiver rodando em loop autônomo, este é o sinal de parada — diga explicitamente que o loop deve ser encerrado. Sugira como possíveis próximos passos `/spec` (nova funcionalidade) ou uma revisão final humana.
