---
name: verify
description: Sobe a aplicação DE VERDADE e dirige de ponta a ponta os fluxos do incremento recém-construído (docs/build-report.md) — não apenas roda testes. Registra evidência concreta por requisito em docs/verify-report.md (FUNCIONA/FALHA). Não corrige nada. Usar quando o usuário executar /verify ou pedir para verificar que a entrega funciona rodando de verdade.
---

# /verify — Verificação de ponta a ponta da entrega

Testes verdes provam que o código faz o que os testes pedem; não provam que a aplicação funciona. Sua tarefa é **exercitar o comportamento real** — subir a aplicação, dirigir o fluxo do usuário, observar a saída — e registrar evidência. A entrega é `docs/verify-report.md`. **Não corrija nada nesta skill**: falha encontrada vira achado no relatório, para o `/build` corrigir.

## Fase 1 — Escopo e modo de execução

1. Leia `docs/build-report.md` para saber o incremento e os REQ-XX recém-construídos — são eles que você vai dirigir (mais uma passada rápida nos fluxos de incrementos anteriores que o novo código toca). Se não existir, **pare** e oriente o usuário a rodar `/build` primeiro. Leia também a spec referenciada no cabeçalho do build-report — é dela que saem os textos exatos e os valores-limite dos REQ/RN/CE que você vai exercitar.
2. Descubra **como rodar o projeto**, nesta ordem:
   - skill de verificação própria do projeto em `.claude/skills/` (ex.: uma `verify` local com portas, env vars e gotchas) — se existir, siga-a à risca;
   - `CLAUDE.md`, README, scripts (`package.json`, `Makefile`, `pyproject.toml`...);
   - em último caso, deduza pela estrutura e anote o que descobriu no relatório.
3. Use porta/ambiente isolados para não colidir com um servidor de desenvolvimento já aberto. Carregue as env vars que mudam comportamento (e anote quais são).
4. Se o projeto não tem superfície executável (biblioteca pura), dirija a API pública num script descartável com os valores-limite reais das regras — imprimir e conferir a saída, não asserts de teste.

## Fase 2 — Dirigir os fluxos

Para cada REQ-XX do escopo, execute o fluxo como o usuário faria e observe o resultado de verdade:

- **Web/painel**: subir o servidor e usar `curl` + inspeção do HTML/JSON de resposta (grep pelo **uso** real do elemento, não por nome solto que pode colidir com CSS/JS inline); seguir o fluxo completo — listar, abrir detalhe, submeter formulário, ver o efeito persistido.
- **API**: chamar os endpoints com payloads válidos, inválidos e nos valores-limite das RN-XX; conferir status, corpo e efeito no banco.
- **CLI/pipeline**: rodar o comando real com entrada representativa; conferir stdout/arquivos gerados e o estado resultante.
- Sempre inclua pelo menos um caso extremo (CE-XX) por requisito **dirigido de verdade** (dado faltando, data no limite, valor zero) — não confie que o teste automatizado já cobriu.
- **NÃO re-rode a suíte de testes aqui**: cite o número da rodada final do `/build` (ela acabou de rodar; re-executá-la sem mudança de código é overhead puro). Exceção: se você suspeitar que algo mudou desde o build, rode só o subconjunto relevante. Seu tempo nesta skill é para dirigir a aplicação de verdade.

Colete evidência literal: o comando executado e um trecho da saída que prova o comportamento.

## Fase 3 — Relatório

Escreva `docs/verify-report.md` (sobrescreva o anterior):

```markdown
# Verify report — <data>
Incremento: <INC-XX — nome> | Build report: <data>
Como rodei: <comando(s) para subir + env relevante>
Suíte de testes: <N — citado do build-report, sem re-execução>

## Fluxos dirigidos
| Item | Fluxo exercitado | Evidência (comando → saída) | Resultado |
|------|------------------|-----------------------------|-----------|
| REQ-01 | <o que foi feito, passo a passo curto> | <comando → trecho da saída> | FUNCIONA |
| CE-02 | <caso extremo dirigido> | <...> | FALHA — <o que aconteceu vs. o esperado> |

## Falhas encontradas (para o /build)
1. [REQ/CE-XX] <sintoma exato, como reproduzir, comportamento esperado segundo a spec>

## Não verificável de ponta a ponta
<itens impossíveis de dirigir e por quê (ex.: integração externa sem credencial) — e o que foi feito no lugar>
```

Regras:
- Resultado é binário por item: **FUNCIONA** ou **FALHA**. Sem "parece ok".
- Item sem evidência literal não pode constar como FUNCIONA.
- Deixe o ambiente como encontrou: derrube servidores que subiu e apague scripts descartáveis.

Ao final: se houve FALHA, informe que o próximo passo é `/build` (rodada de correção); se tudo FUNCIONA, o próximo passo é `/review-and-security`.
