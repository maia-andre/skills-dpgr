"""Lista as linhas não executadas de um relatório JSON do coverage, com a função e o código.

Uso, na raiz do projeto medido:
    python lacunas.py cobertura.json [trecho-do-caminho ...]

Sem trecho, lista todos os arquivos com lacuna, do que tem mais linhas descobertas ao que tem menos.
Só lê arquivos.
"""
import ast
import json
import sys


def funcoes(fonte):
    """(início, fim, nome) de cada função, com a classe na frente quando houver."""
    achadas = []

    def visitar(no, prefixo):
        for filho in ast.iter_child_nodes(no):
            if isinstance(filho, ast.ClassDef):
                visitar(filho, f'{prefixo}{filho.name}.')
            elif isinstance(filho, (ast.FunctionDef, ast.AsyncFunctionDef)):
                achadas.append((filho.lineno, filho.end_lineno, prefixo + filho.name))
                visitar(filho, f'{prefixo}{filho.name}.')
            else:
                visitar(filho, prefixo)

    visitar(ast.parse(fonte), '')
    return achadas


def dono(linha, achadas):
    """A função mais interna que contém a linha."""
    dentro = [f for f in achadas if f[0] <= linha <= f[1]]
    return max(dentro)[2] if dentro else '(módulo)'


def main(argumentos):
    if not argumentos:
        sys.exit(__doc__)
    sys.stdout.reconfigure(encoding='utf-8')
    with open(argumentos[0], encoding='utf-8') as arquivo:
        dados = json.load(arquivo)
    trechos = [t.replace('\\', '/') for t in argumentos[1:]]

    arquivos = sorted(dados['files'].items(), key=lambda par: -len(par[1]['missing_lines']))
    for nome, info in arquivos:
        caminho = nome.replace('\\', '/')
        faltam = info['missing_lines']
        if not faltam or (trechos and not any(t in caminho for t in trechos)):
            continue
        with open(caminho, encoding='utf-8') as arquivo:
            fonte = arquivo.read()
        linhas, achadas = fonte.splitlines(), funcoes(fonte)
        resumo = info['summary']
        print(f"\n== {caminho}: {resumo['percent_covered']:.1f}% "
              f"({len(faltam)} de {resumo['num_statements']} linhas)")
        for numero in faltam:
            print(f'  {numero} {dono(numero, achadas)}: {linhas[numero - 1].strip()[:100]}')

    total = dados['totals']
    print(f"\nTOTAL: {total['percent_covered']:.1f}% "
          f"({total['missing_lines']} de {total['num_statements']} linhas não executadas)")


if __name__ == '__main__':
    main(sys.argv[1:])
