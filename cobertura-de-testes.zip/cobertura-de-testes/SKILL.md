---
name: cobertura-de-testes
description: Mede a cobertura de testes de um projeto Python (pytest) sem alterar o ambiente nem o repositório, aponta as lacunas que importam e, se pedido, leva a medição ao CI (GitLab ou GitHub) primeiro só informando. Use quando o usuário perguntar "qual a cobertura", "o que não está testado", pedir coverage, pytest-cov ou selo de cobertura, ou quiser avaliar Codecov, Coveralls e afins.
---

# Cobertura de testes

Cobertura mostra que a linha **foi executada**, não que o teste pegaria o erro. O percentual situa o projeto; o que gera trabalho útil é a lista de lacunas. Para avaliar a qualidade dos testes que existem, use a `revisar-testes`, se o projeto a tiver.

## Regras

- **Nada muda no projeto para medir.** Sem instalar no venv do projeto, sem editar `requirements`, configuração ou código. No fim, `git status` limpo.
- **Uma corrida.** A suíte completa pode levar minutos: rode uma vez, em segundo plano, e tire dela todos os relatórios.
- **Alvo conferido antes.** Se os testes usam banco ou serviço, confirme que o endereço é local ou descartável. Na dúvida, aborte. Não imprima senha.
- **Número com uma casa decimal.** O relatório arredonda: 94,5% aparece como 95%.
- **Diga o recorte.** O que entrou, o que ficou de fora (e2e, migrações, JavaScript), se é por linha ou por desvio, e em qual commit.

## 1. Entender como o projeto testa

Leia o CI, o `pytest.ini`/`pyproject.toml`, o `.coveragerc` e o `.gitignore`. Anote:
- o comando da suíte, os marcadores e o paralelismo; meça no mesmo recorte do CI;
- as pastas de código da aplicação, que viram o `source`;
- se já existe cobertura configurada. Se existir, use essa configuração.

## 2. Medir

Instale numa pasta temporária, com o Python do projeto (o `coverage` tem parte compilada, que precisa bater com a versão):

```bash
<python-do-projeto> -m pip install --no-deps --target <temp>/cov pytest-cov coverage
```

Configuração em `<temp>/cobertura.ini`, quando o projeto não tiver a sua:

```ini
[run]
source = <pastas da aplicação>
omit = */migrations/*
```

Corrida, na raiz do projeto, com `PYTHONPATH=<temp>/cov` e `COVERAGE_FILE=<temp>/dados.coverage` no ambiente:

```bash
<python-do-projeto> -m pytest -q <recorte do CI> -p no:cacheprovider \
  --cov --cov-config=<temp>/cobertura.ini \
  --cov-report=term-missing \
  --cov-report=json:<temp>/cobertura.json \
  --cov-report=html:<temp>/html
```

- O `--no-deps` conta com `pytest` e `pluggy` já instalados no projeto.
- O plugin soma os processos do `pytest-xdist` sozinho.
- Código rodado em **subprocesso** não é medido desse jeito: o arquivo `.pth` do `coverage` não é lido a partir do `PYTHONPATH`. Trate como descoberto pela medição, não como sem teste.
- Se algum teste falhar, diga antes do percentual: o número deixa de representar a suíte.

## 3. Ler as lacunas

```bash
<python-do-projeto> <pasta desta skill>/scripts/lacunas.py <temp>/cobertura.json [trecho-do-caminho ...]
```

O script lista cada linha não executada com a função e o código. Classifique nesta ordem:

1. **Autorização e identidade:** quem pode ver, editar, assinar.
2. **Integridade:** hash, assinatura, auditoria, dinheiro.
3. **Persistência e fluxo:** transições, escrita no banco, regra de negócio.
4. **Trecho que vai mudar:** o que uma issue aberta está para mexer.
5. **Baixo risco:** 405, `__str__`, tratamento de exceção, `wsgi`/`asgi`. Agrupe numa linha.

Antes de afirmar que falta teste:
- abra o código em volta da linha, para entender a regra;
- **procure nos testes** pelo nome da função, pela mensagem e pela regra. O caso pode estar coberto por outro caminho, ou só no e2e;
- veja se a mesma regra se repete em mais de um ponto, com teste em só um deles. É a lacuna mais comum e a que mais engana.

## 4. Relatar

- Percentual, linhas não executadas e total, resultado da suíte, duração, commit e recorte.
- Tabela curta: as áreas sensíveis e as piores.
- Lacunas que importam, com `arquivo:linha`, a regra em uma frase e o que falta.
- O caminho completo do relatório HTML, com aviso de que a pasta é temporária.

Issue, teste novo e mudança no CI só quando o usuário pedir. Teste para regra que já existe precisa **falhar quando a regra é retirada**; sem isso, só aumenta o percentual.

## 5. Levar ao CI, se pedido

Comece **só informando**, sem meta. Plugin com versão fixada, instalado no job de testes, fora das dependências que vão para a imagem ou para a produção. Confira se a auditoria de dependências do projeto o alcança e diga se não alcançar.

**GitLab** (recursos do plano Free):

```yaml
test:
  script:
    - pip install -r requirements.txt pytest-cov==<versão>
    - pytest <recorte> --cov --cov-report=term-missing --cov-report=xml
  coverage: '/TOTAL.*? (100(?:\.0+)?\%|[1-9]?\d(?:\.\d+)?\%)$/'
  artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura
        path: coverage.xml
```

O `coverage:` alimenta o percentual, o histórico e o selo; o XML alimenta as linhas marcadas no diff do MR. São independentes: configure os dois. A regra de aprovação `Coverage-Check` é do Premium.

**GitHub Actions:** o `pytest-cov` roda igual, mas o percentual fica no log do job. Comentário no PR e histórico pedem action ou serviço à parte.

Coloque `coverage.xml` e `htmlcov/` no `.gitignore`. Depois da primeira execução, confira se o percentual aparece, compare com a medição local e anote a duração do job antes e depois.

**Meta**, quando o time quiser: parta do valor medido e não deixe cair (`--cov-fail-under=N`). Meta alta logo de início produz teste raso.

## 6. Avaliar serviço externo (Codecov, Coveralls...)

Confira na documentação atual, sem responder de memória:
- o que é enviado, o que fica guardado e que acesso o aplicativo pede ao repositório;
- plano e limites para repositório privado;
- se alcança o servidor Git, quando ele é interno;
- quais segredos existem no job que faria o envio. Em 2021, o uploader do Codecov foi adulterado e extraiu variáveis de ambiente do CI (post-mortem: https://about.codecov.io/apr-2021-post-mortem/).

Repositório público, sem segredo no job de testes, é o caso favorável. Em repositório privado ou interno, prefira a medição no próprio CI.

## Fontes

- pytest-cov: https://pytest-cov.readthedocs.io/
- coverage.py: https://coverage.readthedocs.io/
- GitLab, Code coverage: https://docs.gitlab.com/ci/testing/code_coverage/
