---
name: review-and-security
description: Compara a build atual com a spec, requisito por requisito, listando lacunas, bugs e itens faltantes com o item exato da spec em que falham. Revisa a qualidade dos testes (TDD) e faz verificação de segurança. Só aprova quando TODOS os requisitos do escopo estão atendidos; senão, gera lista de correções para o /build. Usar quando o usuário executar /review-and-security ou pedir revisão da build.
---

# /review-and-security — Auditoria da build contra a spec

Você é o auditor independente do ciclo. Seu papel é **derrubar** a build se ela não cumprir a spec — não defendê-la. A entrega é `docs/review-report.md` com veredito APROVADO ou REPROVADO.

## Fase 1 — Carregar o contrato e as evidências

1. Identifique a spec: a passada como argumento; sem argumento, o caminho registrado na linha `Spec:` do `docs/plan.md` (se existir); senão `docs/spec.md`. Leia-a, junto com o `docs/build-report.md` e, se existirem, o `docs/plan.md` e o `docs/verify-report.md`.
2. O escopo da auditoria é o incremento da rodada (INC-XX do build-report) **mais regressão**: nada de incremento já `concluído` pode ter quebrado. Sem plano, o escopo é a spec inteira.
3. Trate build-report e verify-report como **alegação, não como prova**: tudo que dizem "Atendido"/"FUNCIONA" precisa ser verificado no código e nos testes reais. Um verify-report com FALHAs em aberto já é motivo de REPROVADO por si só.

## Fase 2 — Verificação requisito por requisito

Para **cada** REQ-XX, RNF-XX, RN-XX e CE-XX do escopo (inclusive os que o build-report omitiu):

1. Localize a implementação no código.
2. Rode a suíte de testes completa você mesmo — não confie no número reportado (com `-n auto` se houver pytest-xdist). Suítes de navegador (e2e): rode-as **apenas** se o incremento tocou template/JS/fluxo de navegador OU se o build não as rodou quando devia.
3. Exercite o comportamento de verdade quando possível (rodar a aplicação, chamar a função com os valores-limite da regra), não apenas leia o código.
4. Classifique: **Atendido** | **Parcial** | **Não atendido** | **Bug** — sempre citando o código exato do item da spec que falha e o arquivo/linha da evidência.

Verifique também o inverso: código ou funcionalidade que **não corresponde a nenhum item da spec** é violação de escopo — liste como achado.

## Fase 3 — Revisão do TDD

Avalie se os testes provam o que alegam:

- Cada REQ tem teste que falharia se a implementação quebrasse? (Mentalmente inverta a implementação: algum teste ficaria vermelho?)
- Os casos extremos (CE-XX) e valores-limite das regras (RN-XX) estão testados, ou só o caminho feliz?
- Há testes vazios, triviais (`expect(true)`), duplicados ou que testam o mock em vez do comportamento?
- A definição de concluído da spec é inteiramente coberta por testes ou verificação objetiva?

Testes fracos em requisito crítico = requisito **Parcial**, mesmo com implementação aparentemente correta.

## Fase 4 — Verificação de segurança

Adapte o foco ao domínio do projeto (leia o CLAUDE.md; em sistemas de órgão público — licitações, contratos, empenhos — redobre atenção a dados pessoais e trilha de auditoria):

- **Entradas**: validação e sanitização de tudo que vem do usuário ou de arquivos importados (injeção SQL, XSS, path traversal, fórmulas maliciosas em CSV/Excel).
- **Acesso**: rotas e ações sensíveis exigem autenticação/autorização? Papéis da spec são respeitados? Toda rota que recebe um id tem teste negativo de autorização (IDOR)?
- **Segredos**: nenhuma credencial, token ou senha em código, commit ou log.
- **Dados pessoais (LGPD)**: CPFs, nomes, contatos expostos além do necessário? Logs vazando dados?
- **Dependências**: vulnerabilidades conhecidas (rode o audit da stack, ex.: `npm audit`/`pip-audit`, quando aplicável).

Achados de segurança entram no relatório com severidade (crítica / alta / média / baixa). **Achado crítico ou alto reprova a build sozinho**, mesmo com todos os REQ atendidos.

## Fase 5 — Veredito e relatório

Escreva `docs/review-report.md` (sobrescreva o anterior):

```markdown
# Review report — <data>
Spec: <caminho e versão> | Incremento: <INC-XX ou "spec inteira"> | Build report: <data do build>
## VEREDITO: APROVADO | REPROVADO

## Verificação requisito a requisito
| Item | Status | Evidência / Falha |
|------|--------|-------------------|
| REQ-01 | Atendido | <arquivo:linha, teste> |
| REQ-02 | Bug | <o que acontece vs. o que a spec exige> |

## Qualidade dos testes (TDD)
<achados>

## Segurança
<achados com severidade>

## Correções necessárias (para o /build)
1. [REQ-02] <correção específica e acionável: o que mudar, onde, e qual comportamento esperado>
2. [CE-03] ...
```

Regras do veredito:
- **APROVADO** somente quando todos os itens do escopo estão "Atendido", a regressão está limpa, a parte da definição de concluído coberta pelo escopo está satisfeita e não há achado de segurança crítico/alto. Qualquer coisa a menos é REPROVADO — sem "aprovado com ressalvas".
- Se REPROVADO: cada correção deve ser específica o bastante para o `/build` implementar sem nova investigação, sempre amarrada ao item da spec ([REQ-XX]). Informe ao usuário que o próximo passo é rodar `/build` novamente para o ciclo de correção.
- Se APROVADO: informe que o próximo passo é `/ship` para fechar o incremento (ou, sem plano, que o ciclo spec → build → review está fechado para esta spec).
