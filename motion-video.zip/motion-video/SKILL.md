---
name: motion-video
description: Produz vídeos em "motion" (tipografia cinética, telas animadas, números, mapas, réplicas de sistema) escritos como código — HTML + JS com tempo determinístico, narração sintética ou gravada, música original, render para MP4 e conferência de quadros e pronúncia. Começa entrevistando o usuário (objetivo, público, formato, arquivos de referência, voz, música, identidade visual, idiomas, quem aprova) e só depois roteiriza e constrói. Usar quando o usuário pedir um vídeo explicativo, de treinamento, de lançamento, vitrine, pílula para redes, ou executar /motion-video.
---

# /motion-video — vídeo em motion a partir de uma entrevista

Você é diretor, roteirista e animador. O vídeo é **código que se regenera**: mudou o roteiro → regenera
a voz → as cenas se reajustam sozinhas → re-renderiza só o que mudou. Nada sai sem conferência.

```
entrevista → briefing.md → roteiro (fala × tela) → narracao.json → [narrar] → audio/bN.wav + timing.js
                                                                          ↓
                    episodio.html (Motor.cena / timeline pausada)  →  [render]  →  MP4
                                                                          ↓
                                                         [conferir] quadros × frases + ouvido humano
```

**Regra de ouro:** narração primeiro, animação depois. A duração de cada cena é o áudio do bloco + `pad`.
Todo texto-chave entra amarrado ao início da frase que o diz (`T.frase(i)`), nunca "no olho".

## Fase 0 — Ambiente (antes de qualquer coisa)

1. O projeto já tem o motor? Procure `lib/motor.js` + `render/render.py` + `tts/narrar.py`. Se sim, use o
   que existe e leia o `CLAUDE.md` dele (pode ter convenções próprias que valem mais que esta skill).
2. Se não tem, instale o kit desta skill: siga `references/instalacao.md` (copiar `kit/`, venv,
   Chromium do Playwright, ffmpeg). **Nunca `pip` no Python do sistema**: só no `.venv` do projeto.
3. Cada vídeo mora em `videos/<nome>/`, copiado de `kit/modelo/`.

## Fase 1 — Entrevista (não pule)

Objetivo: sair com um `videos/<nome>/briefing.md` que o usuário aprovou. Use a ferramenta de perguntas
do ambiente quando houver (várias perguntas de múltipla escolha por rodada); sem ela, faça **rodadas
curtas** de 3 a 5 perguntas numeradas, com uma sugestão padrão em cada uma para o usuário só confirmar.
Não pergunte o que dá para descobrir sozinho (abra os arquivos que ele mandar antes de perguntar sobre eles).

Roteiro completo de perguntas, com o porquê de cada uma e os padrões sugeridos: `references/entrevista.md`.
Em resumo, cinco rodadas:

1. **Objetivo e público** — que tipo de vídeo, para quem, o que a pessoa deve saber/fazer ao final,
   onde vai passar (define formato 16:9 / 9:16, duração e se precisa funcionar sem som).
2. **Material de referência** — já existe roteiro? Documentos, apresentações, site, prints de sistema,
   fotos, logos, manual de marca, vídeos que ele gosta como estilo? Números reais ou ilustrativos?
   Peça os arquivos e o caminho; leia tudo antes da rodada seguinte.
3. **Áudio** — narração (voz sintética local, voz em nuvem, voz gravada por ele, ou sem narração),
   idioma(s), tom/persona do narrador; música (original sintetizada, arquivo dele com licença, nenhuma);
   efeitos sonoros pontuais.
4. **Visual** — identidade existente ou a criar, personagem/narrador visual, estilo dominante,
   restrições (logos de terceiros, nomes de pessoas, dados sensíveis).
5. **Entrega e validação** — variantes (com/sem logos, outros idiomas, vertical), legenda, prazo,
   **quem aprova** e por qual canal, onde será publicado.

Feche escrevendo `briefing.md` (modelo em `references/entrevista.md`) e peça um "ok" explícito.
Preencha `projeto.json` (fase `roteiro`).

## Fase 2 — Roteiro (fala × tela)

Escreva `roteiro.md` com uma tabela por bloco: **o que se fala** e **o que aparece**. Estruturas
prontas e regras de redação para voz: `references/roteiro.md`. O essencial:

- Um bloco = uma cena = uma ideia. 3–5 min ≈ 330–450 palavras a ~145 ppm (vozes rápidas chegam a 175).
- **Texto em tela ≠ transcrição**: só frases-chave, números, nomes. A legenda é outro arquivo.
- Frases curtas. Número no meio de frase longa embola: dê ao número uma frase própria.
- Números **exatos na tela**, arredondados e por extenso na fala.
- Lei, norma, referência: **carimbo em tela**, não leitura em voz ("artigo tal, inciso tal").
- Caso citado na fala ganha números e raciocínio na tela, não só menção.
- Pessoas fictícias: cargo ou unidade genérica, nunca nome inventado, apelido ou trocadilho.
- Valores não confirmados: rodapé "Valores ilustrativos".

Mostre o roteiro e espere aprovação antes de narrar. Depois passe as falas para `narracao.json`.

## Fase 3 — Narração

Detalhes, vozes, pronúncia e limites do ASR: `references/narracao.md`.

```bash
.venv/bin/python -m tts.narrar videos/<nome> --provedor silencio   # monta as cenas antes de escolher a voz
.venv/bin/python -m tts.narrar videos/<nome>                       # voz do narracao.json, com conferência
.venv/bin/python -m tts.narrar videos/<nome> --blocos b2,b4        # só o que mudou (vírgula, sem espaço)
```

- Cada frase é gerada até `tentativas` vezes e conferida por Whisper; fica a melhor. ✗ = **ouça** antes
  de mexer: às vezes o erro é do ASR (ele não distingue siglas soletradas).
- Corrija pronúncia nesta ordem: reescrever a frase → dicionário `tts/pronuncia.json` por voz →
  fonemas. Teste a grafia antes de registrar; registre o motivo em `historico`.
- Voz gravada pelo usuário: `scripts/fatiar_gravacao.py` (roteiro de gravação + fatiamento por pausas)
  e provedor `gravacao`.
- Voz de pessoa real ou clonagem: **só com autorização escrita** de quem cede a voz.

## Fase 4 — Cenas

API do motor, componentes, os dois estilos (cena por bloco × timeline GSAP pausada), linguagem visual e
armadilhas: `references/cenas.md`. O essencial:

- **Determinismo**: todo estado visual é função pura de `t`. Proibido CSS `transition`/`animation`,
  `requestAnimationFrame`, `setTimeout`, `Date.now()`, `Math.random()` sem semente, estado acumulado
  entre quadros. O render pula quadros e roda em paralelo, fora de ordem.
- **Nada da internet** na cena (fontes, imagens, scripts de CDN): tudo local em `marca/` ou na pasta do vídeo.
- Todo texto-chave leva `data-frase="bN.K"` (K começa em 1): é o que a conferência verifica.
- Uma ideia por vez; o que sai, sai antes do próximo entrar. Margens ≥ 160 px, corpo ≥ 26 px.
- Prévia: abra `episodio.html` no navegador (▶, arrastar, ← → quadro a quadro, espaço = play com áudio).

## Fase 5 — Áudio de apoio

Música e efeitos: `references/audio.md`.

```bash
.venv/bin/python scripts/gerar_sons.py                                   # marca/sons/: guardar, acerto, encerramento
.venv/bin/python scripts/trilha.py videos/<nome> --clima claro --bpm 92   # trilha ORIGINAL no tempo do vídeo
```

- **Sem silêncio mudo longo** (> ~1,5 s soa como defeito): segure a tela com `pausa_depois` curto +
  efeito leve (`Motor.efeito('guardar', t)`). Efeito pontual, não no vídeo todo.
- Música de terceiros quase sempre tem direitos: prefira a trilha sintetizada ou um arquivo com licença clara.
- A trilha lê o `Motor.plano()`: mudou a narração, rode o `trilha.py` de novo **antes** do render.

## Fase 6 — Render e conferência

```bash
.venv/bin/python render/render.py videos/<nome> --rascunho                 # 960×540 @15fps, para revisar
.venv/bin/python render/render.py videos/<nome> --de 20 --ate 35           # só um trecho
.venv/bin/python render/render.py videos/<nome> --fundo videos/<nome>/audio/trilha.wav --ducking 6
.venv/bin/python render/conferir.py videos/<nome>                          # sincronia + MP4 + pronúncia
```

Render paralelo e retomável (segmentos com hash do HTML, timing, `lib/` e `marca/`). Áudio a −16 LUFS.

**Conferência é obrigatória** (`references/conferencia.md`): rode `conferir.py`, **abra e olhe**
`out/conferencia/mosaico.jpg` comparando com `legenda.txt` (texto certo na hora certa? cortado? sobra
da cena anterior? rodapé de valores ilustrativos?) e liste o que depende do ouvido humano (siglas,
nomes próprios, frases com ✗).

## Fase 7 — Validação e entrega

- Rodadas de revisão com terceiros: mande **trechos curtos** (`--de/--ate`) em `out/validacao/`, não o
  vídeo inteiro a cada ajuste. Para revisor externo, uma página com os vídeos, as decisões em aberto
  (múltipla escolha) e um botão "copiar respostas" funciona melhor que troca de mensagens.
- Dado que muda (números de site, telas de sistema): **reconfira e recapture antes de cada render final**.
- Variantes (sem logos, outro idioma, vertical) são parâmetros na URL (`--query`), não cópias do
  vídeo: `references/variantes.md`.
- Entregue com uma linha: duração, voz, o que foi conferido, o que o usuário precisa ouvir.
- Registre decisões no `CLAUDE.md` do vídeo e o estado no `projeto.json` (fase, histórico).
- Publicar (push, release, upload, enviar ao revisor) é decisão do usuário: pergunte antes.

## Lições que custaram caro

Lista completa, com contexto: `references/licoes.md`. Leia antes do primeiro vídeo de um projeto.
