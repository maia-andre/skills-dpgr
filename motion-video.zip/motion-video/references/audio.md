# Música e efeitos

## Efeitos sonoros

`scripts/gerar_sons.py` sintetiza `marca/sons/` (sem download, determinístico):

| Som | Uso |
|---|---|
| `guardar` | sino suave: frase final / "Para guardar" |
| `acerto` | "ding" curto: entrada do ✔, número revelado |
| `encerramento` | duas notas ascendentes: cartão final |

No episódio, **uma vez, fora de `quadro`**: `Motor.efeito('acerto', Motor.frase('b4.2').t0, -20)`
(tempo global em segundos, volume em dB). O render lê `window.EFEITOS` e o `render/mix.py` posiciona.
Som novo: acrescente em `gerar_sons.py` ou ponha um `.wav` próprio em `marca/sons/`.

**Para que servem:** tirar silêncio. Pausa muda maior que ~1,5 s soa como defeito ("silêncio
constrangedor"). Segure a tela com `pausa_depois` curto (1,2–2 s) + efeito leve. Efeito em toda
transição cansa: use nos pontos de virada.

## Música de fundo

**Direitos:** música comercial (inclusive "só um trecho", inclusive trilha de filme famoso) não pode.
Bibliotecas "royalty free" têm licença própria: leia. O caminho seguro é a trilha original sintetizada.

```bash
.venv/bin/python scripts/trilha.py videos/<nome> --clima claro|noturno|neutro --bpm 92 --semente 11
.venv/bin/python render/render.py videos/<nome> --fundo videos/<nome>/audio/trilha.wav --ducking 6
```

- A trilha lê o `Motor.plano()` do próprio episódio: intro só com pad no 1º bloco, arpejo até o
  penúltimo, acorde final soando no último. Mudou a narração → **rode o `trilha.py` de novo antes do render**.
- Para um arco narrativo (ex.: "noite" em menor que "amanhece" em maior numa virada), edite o script
  marcando as viradas por `Motor.frase(...)`/início de bloco, nunca por segundos fixos.
- Semente fixa por vídeo (ex.: número do episódio) → séries com trilhas parecidas mas não iguais.
- Volumes: com voz, `--fundo-db -24` (padrão) e `--ducking 6`; **sem voz**, `--fundo-db -14` e sem ducking.
- Arquivo do usuário: `--fundo caminho.mp3` funciona igual (é repetido em loop se for curto); confirme a licença.

## Mix final

`render/mix.py` monta a trilha a 48 kHz: voz de cada bloco no `inicio` do plano + efeitos + música
(com ducking opcional), limita picos, e o `render.py` normaliza a −16 LUFS (padrão de plataformas
de vídeo), AAC 192 kb/s. Um piso de ruído a −100 dB evita falha do encoder em trechos 100% mudos.
