# Narração

A narração é a **fonte do tempo** do vídeo. `tts/narrar.py` gera, por bloco, `audio/bN.wav` e o tempo de
cada frase em `audio/timing.json` + `audio/timing.js` (`window.TIMING.bN.frases[i].t`), que o HTML lê.

## Provedores do kit

| Provedor | Voz | Onde roda | Como obter | Notas |
|---|---|---|---|---|
| `silencio` | — | — | — | duração estimada (~145 ppm). Para montar e renderizar cenas antes de decidir a voz. |
| `kokoro` | pt: `pm_alex` (masc.), `pf_dora` (fem.); en/es/fr/it também | CPU, offline | `pip install kokoro-onnx` + `scripts/baixar_modelos.py kokoro` (GitHub) | boa relação qualidade/custo; aceita fonemas IPA para siglas. Dora > Alex na escuta. |
| `piper-dii` | pt-BR feminina | CPU, rápida | `scripts/baixar_modelos.py piper-dii` (GitHub) | "quase no ideal"; "língua presa" no R depois de consoante, que dicionário não corrige. |
| `fish` | biblioteca de vozes da Fish Audio (`--voz <reference_id>`) | nuvem | `FISH_API_KEY` no `.env`; `pip install httpx` | a mais fluida que testamos em pt-BR. Modo `free` (uso justo) e `pro` (pago, com teto `FISH_ORCAMENTO_USD`); nunca passa de free para pro sozinho. Deixe a normalização da API **desligada** (estraga números); o kit expande números localmente. Cache por conteúdo: re-render não paga de novo. |
| `gravacao` | voz humana | — | `scripts/fatiar_gravacao.py` | uma tentativa, sem dicionário, sem cache; Whisper ainda confere se a frase foi lida inteira. |

Provedor novo = um arquivo em `tts/provedores/` com uma classe que herda de `Provedor` e implementa
`_sintetizar_texto(texto, tentativa) -> (float32 mono, sr)`, registrada em `tts/provedores/__init__.py`.
Vozes que já testamos e descartamos: sotaque estrangeiro caricato, vozes de biblioteca "idosas" (soam
cômicas, sem credibilidade), clones de personagens/dublagem e de pessoas reais (**nunca use**).

## Escolher a voz

1. Monte o vídeo com `--provedor silencio` primeiro; a voz não bloqueia as cenas.
2. Gere as **3–5 frases mais difíceis do roteiro** (siglas, números, nomes próprios, pergunta) em 2–3
   vozes candidatas e monte uma página simples com players lado a lado e nota 1–5 por frase. O
   usuário escolhe **de ouvido**; o Whisper só filtra o grosseiro.
3. Critérios, nesta ordem: pronúncia de siglas e números · naturalidade em frase longa · timbre adequado
   ao narrador · roda onde precisa rodar (CPU? rede liberada?) · licença · custo.
4. Velocidade: alvo ~145 ppm para didático; vozes naturais rápidas (~175 ppm) a 1.0 soam melhor que
   desaceleradas para 0,85–0,92 (perdem naturalidade). Desacelere só frases pontuais.
5. Registre a decisão (voz, por quê, data) no `CLAUDE.md` do vídeo e no `projeto.json`.

A geração em nuvem varia a cada chamada (amostragem): a mesma frase pode sair melhor numa nova
tentativa. Por isso o `narrar` gera até `tentativas` vezes e fica com a de maior nota.

## Conferência de pronúncia (Whisper) e seus limites

- ASR: Whisper small em ONNX via sherpa-onnx (`scripts/baixar_modelos.py whisper`, ~640 MB do GitHub;
  troque por `-base` no script para ~210 MB). Sem ele, o `narrar` segue sem conferência e avisa.
- Nota = semelhança roteiro × transcrição (números normalizados por extenso, sem acento). `limiar` 0,85.
- `palavras_criticas` (dicionário) + `checar` (roteiro/frase) precisam aparecer na transcrição.
- **O ASR não distingue siglas soletradas** (ouve "ETP" como "ATP" em qualquer grafia). Sigla se aprova
  **de ouvido**; depois registre a transcrição aceita em `equivalentes_asr`.
- ✗ no relatório = **ouça antes de mexer**. Não "conserte" o que soa certo.
- Contrações: a voz diz "num lugar" e o ASR escreve "em um lugar" (nota 0,8, ✗ falso). Ponha a forma
  do ASR em `"expect"` da frase, ou escreva por extenso no roteiro.
- **Kokoro e Piper sem ruído são determinísticas**: a mesma frase sai igual em toda tentativa, então
  `tentativas` não ajuda; reescreva ou ajuste a velocidade. Vozes em nuvem variam a cada chamada.

## Corrigir pronúncia (`tts/pronuncia.json`)

Ordem de tentativa:
1. **Reescrever a frase** (estrutura): resolve número embolado, emenda de vogais, construção ambígua.
2. **Dicionário** `por_provedor.<voz>`: grafia fonética só para aquela voz. `texto` vale para todas:
   só com prova de que melhora em todas.
3. **Fonemas** (`fonemas.kokoro`): IPA para vozes que aceitam (sigla → `ˈe tˈe pˈe`).

**Regra de evidência:** teste a grafia (ASR + ouvido) **antes** de registrar. Grafia "esperta" costuma
piorar: sílaba acentuada isolada com hífen ("bê-dê-í") pode ser lida com o nome do acento. Siglas comuns
cruas (BDI, PNCP, NR-17) muitas vezes saem certas. Exemplos de correções que funcionaram: "Termo" com E
aberto → "têrmo"; "Antaq" → "Antáqui"; "LICIT.AI" → "Licitaí"; "IA" no meio de frase → "I.A.".
Registre cada achado em `historico` com data, voz e resultado. Teste rápido de grafias:

```bash
.venv/bin/python - <<'E'
from tts.provedores import obter; from tts import conferencia_whisper as cw
p = obter('kokoro', voz='pf_dora')
for v in ['NomeDoSistema', 'Nome do Sistema', 'Nômedo Sistema']:
    a, sr = p._sintetizar_texto(f'No {v}, o código traz a descrição.', 0)
    print(v, '->', cw.transcrever(a, sr))
E
```

## Voz gravada pelo usuário

1. `scripts/fatiar_gravacao.py videos/<nome> --roteiro` → `gravacao/ROTEIRO.txt` com as frases e ids.
2. O usuário grava **um arquivo por bloco** (`gravacao/b1.wav`…), lendo as frases na ordem com ~1 s de
   pausa entre elas (vírgula pode ter pausa curta; o script corta só nas maiores). Ou uma frase por
   arquivo (`gravacao/b1.2.wav`). Celular serve; ambiente silencioso importa mais que o microfone.
3. `scripts/fatiar_gravacao.py videos/<nome>` fatia e avisa o bloco cujo número de pausas não bate.
4. `"voz": {"provedor": "gravacao"}` no `narracao.json` → `python -m tts.narrar videos/<nome>`.
Regravou uma frase? Rode o fatiador (ou troque o `bN.K.wav`) e o `narrar` de novo: não há cache.

## Clonagem de voz

Só com **autorização escrita** de quem cede a voz, e só quando o usuário decidir. A amostra sai da
máquina se o serviço for em nuvem. Nunca clone voz de terceiros, de personagens ou de figuras públicas.

## Checklist antes de dizer "narração pronta"

- [ ] `audio/relatorio.json` sem ✗, ou cada ✗ ouvido e justificado.
- [ ] Siglas e nomes próprios ouvidos ao menos uma vez (ou listados para o usuário ouvir).
- [ ] Achados de pronúncia registrados no `historico` do dicionário.
- [ ] `projeto.json` atualizado (fase `narracao`, voz usada).
