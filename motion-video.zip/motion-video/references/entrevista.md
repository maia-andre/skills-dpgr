# Entrevista

O vídeo errado custa caro: cada ida e volta depois do render é narração, cena e conferência de novo.
A entrevista existe para errar no papel. Regras:

- **Rodadas curtas** (3–5 perguntas), cada pergunta com opções e um **padrão sugerido** marcado. O usuário
  deve poder responder "tudo padrão" e seguir.
- **Leia antes de perguntar.** Se ele mandou um PDF, site ou apresentação, extraia dali público, números e
  tom e pergunte só para confirmar ("vi que o público é X, certo?").
- **Não pergunte o que é decisão técnica sua** (fps, codec, nome de arquivo). Decida e registre.
- Pare de perguntar quando der para escrever o briefing. Lacuna pequena vira "padrão adotado" no briefing.

## Rodada 1 — Objetivo e público

| Pergunta | Por que importa | Padrão sugerido |
|---|---|---|
| Que tipo de vídeo? (treinamento/tutorial · lançamento/divulgação · vitrine para convencer · explicativo de conceito · pílula para redes) | define a estrutura do roteiro e o tom | explicativo |
| Quem assiste? Sabe o quê do assunto? | vocabulário, ritmo, o que dá para pular | leigo no tema, adulto, profissional |
| O que a pessoa deve **saber ou fazer** ao final? (uma frase) | vira o "Para guardar" / a chamada final | — (obrigatório) |
| Onde vai passar? (YouTube · intranet/EAD · WhatsApp/Instagram · apresentação ao vivo/telão · e-mail) | 16:9 × 9:16, duração, legenda, se precisa funcionar **sem som** | YouTube, 16:9 |
| Duração alvo? | 1 min ≈ 145 palavras de fala | 2–3 min (lançamento), 3–5 min (treinamento), 30–60 s (redes) |
| É parte de uma série? | componentes e identidade reaproveitados, barra de progresso, gancho para o próximo | avulso |

## Rodada 2 — Material de referência

| Pergunta | Por que importa | Padrão |
|---|---|---|
| Já existe roteiro ou texto base? | se existe, você adapta para voz em vez de criar | não; eu escrevo a partir do material |
| Que arquivos de referência você tem? (documentos, apresentações, planilhas, site, prints do sistema, fotos, logos, manual de marca) Mande os caminhos. | conteúdo e números saem daí, **nunca inventados** | — |
| Há algum vídeo, peça ou site cujo **estilo** você gosta? | referência visual vale mais que adjetivos | — |
| Os números são reais e podem aparecer? Mudam com o tempo (contadores de site, indicadores)? | reais sem tarja × "valores ilustrativos"; reconferir antes do render final | ilustrativos com tarja |
| Vai mostrar telas de um sistema? Ele está acessível para capturar agora? | capturas reais recentes; sistema fora do ar trava a produção | — |
| Há informação sensível ou de circulação restrita? | define onde o vídeo pode passar e o que fica fora do git | não |

Guarde o material em `videos/<nome>/referencias/` (fora do git se for pesado, sensível ou de terceiros).

## Rodada 3 — Áudio

| Pergunta | Opções e consequências | Padrão |
|---|---|---|
| Terá narração? | **Voz sintética local** (CPU, offline, de graça; qualidade boa, peca em siglas) · **voz em nuvem** (mais natural; precisa de chave/conta e rede liberada; o texto sai da máquina) · **voz gravada por você** (mais humana; exige microfone razoável e ambiente silencioso; eu fatio e sincronizo) · **sem narração** (texto + música; o texto em tela passa a ser o roteiro inteiro, ritmo por leitura) | sintética local; testar 2–3 vozes antes de decidir |
| Idioma(s)? | cada idioma = narração + textos de tela próprios; revisor nativo para cada um | só pt-BR |
| Tom / persona do narrador? (colega experiente · institucional sóbrio · entusiasmado · personagem com nome) | personagem com nome/arte exige **autorização** de quem é dono; até lá, placeholder visível | colega experiente, 1ª pessoa, sem jargão |
| Voz masculina ou feminina? Mais jovem ou mais madura? | vozes "idosas" de biblioteca costumam soar caricatas | deixar a escuta decidir |
| Música de fundo? | **original sintetizada** (livre, discreta, no tempo do vídeo) · **arquivo seu** (só com licença clara: "achei no YouTube" não serve) · **nenhuma** | original, discreta, com ducking sob a voz |
| Efeitos sonoros? | pontuais: acerto, frase-chave, encerramento; servem para tirar silêncio | sim, poucos |

Se for voz em nuvem: pergunte se a rede onde ele vai rodar libera o serviço e se o texto pode sair da
máquina (roteiro ainda não aprovado, dado restrito).

## Rodada 4 — Visual

| Pergunta | Por que importa | Padrão |
|---|---|---|
| Existe identidade visual (cores, fontes, logo, manual)? De quem é a marca? | vídeo de iniciativa de terceiros usa a identidade **deles**, não a sua | criar uma sóbria: fundo escuro, um destaque |
| Fontes? Os arquivos estão disponíveis e a licença permite embutir? | render offline: fonte local em `marca/fontes/` | Inter / Inter Tight ou similar livre |
| Estilo dominante? (tipografia cinética · telas de sistema animadas · fotos reais · gráficos e números · mapas · diagramas · ilustração) | define os componentes a construir | tipografia + números |
| Logos de parceiros/instituições? Tamanhos proporcionais importam a quem? | logos de terceiros só com permissão; peso visual equilibrado | sem logos |
| Pessoas reais aparecem (foto, nome, voz)? | autorização; na dúvida, cargo/unidade genérica | não |

## Rodada 5 — Entrega e validação

| Pergunta | Por que importa | Padrão |
|---|---|---|
| Quem aprova o vídeo, além de você? Por qual canal você leva a revisão? | rodadas de validação, página de revisão, prazos | só você |
| Variantes? (com/sem logos · outros idiomas · vertical 9:16 · versão curta) | viram parâmetros `--query`, planejados desde o início | uma versão 16:9 |
| Legenda? (queimada no vídeo · arquivo .srt · a da plataforma) | YouTube gera legenda automática; queimada é para redes sem som | a da plataforma |
| Prazo? | rascunho silencioso cedo, voz e acabamento depois | — |
| Onde o MP4 final fica? (release, drive, intranet) | vídeos ficam **fora do git** | pasta `out/` |

## Modelo de `briefing.md`

```markdown
# Briefing — <título provisório>
Data: <AAAA-MM-DD> · Aprovado por: <quem> em <data>

## Objetivo
<o que a pessoa deve saber/fazer ao final, em uma frase>

## Público e contexto
<quem, o que já sabe, onde vai assistir>

## Formato
<16:9 1920×1080 @30 | 9:16 1080×1920> · duração alvo <x min> · <com som | precisa funcionar sem som>

## Estrutura proposta
<estrutura escolhida em references/roteiro.md, com os blocos em uma linha cada>

## Material de referência
- <arquivo/URL> — <o que se usa dele>
Números: <reais (fonte, data da coleta) | ilustrativos com tarja>

## Áudio
Narração: <provedor/voz candidata | gravada | sem> · idioma(s): <…> · tom: <…>
Música: <original sintetizada, clima | arquivo (licença) | nenhuma> · efeitos: <…>

## Visual
Identidade: <de quem; cores; fontes> · estilo: <…> · restrições: <logos, pessoas, dados>

## Entrega
Variantes: <…> · legenda: <…> · validação: <quem, canal> · destino: <…> · prazo: <…>

## Padrões adotados sem pergunta
- <decisões que você tomou e o usuário pode reverter>

## Em aberto
- <o que depende de terceiros: autorização de personagem, dado a confirmar…>
```
