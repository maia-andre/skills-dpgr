# Conferência

Nada sai sem conferir. O render "dá certo" mesmo quando o vídeo está errado.

```bash
.venv/bin/python render/conferir.py videos/<nome>
RENDER_QUERY="lang=en&semlogos" .venv/bin/python render/conferir.py videos/<nome>   # variante
```

Verifica, nesta ordem:
1. **Sincronia (no HTML, sem MP4):** cada `[data-frase="bN.K"]` invisível (opacidade < 0,3) 0,25 s antes
   do início da frase K e visível (> 0,7) 0,9 s depois. Avisa se o elemento sai do quadro.
2. **MP4 mais recente em `out/`:** duração = plano (±0,2 s), faixa de áudio presente; extrai um quadro em
   cada frase-chave para `out/conferencia/` + `mosaico.jpg` + `legenda.txt`.
3. **Pronúncia:** resumo de `audio/relatorio.json`.
Sai com código 1 se houver falha.

**Falsos positivos conhecidos:** elemento revelado por `clip-path`/máscara (a opacidade não muda) e
elemento que entra de propósito no meio da frase. Confirme no quadro e anote no `CLAUDE.md` do vídeo
para não investigar de novo.

## Olhar o mosaico (obrigatório)

Abra `out/conferencia/mosaico.jpg` com a ferramenta de imagem e compare cada célula com `legenda.txt`:
- O texto da tela corresponde ao que está sendo falado naquele instante?
- Algo cortado, sobreposto, fora da margem, ilegível (corpo pequeno, contraste baixo)?
- Sobrou elemento da cena anterior? Entrou cedo demais?
- Rodapé "Valores ilustrativos" onde há valores não confirmados? Fonte e data onde há valores reais?
- Logos proporcionais? Títulos com margem no topo?

Quadro suspeito → extraia isolado no tempo exato e leia:
`ffmpeg -ss <t> -i out/<nome>.mp4 -frames:v 1 <scratch>/q.jpg`.
Para revisar o fim de cada frase (texto que sai cedo), extraia também em `Motor.frase(id).fim - 0.1`.

## Ouvir (o que a máquina não pega)

- O ASR não distingue siglas soletradas. Siglas e nomes próprios: ouça ou liste para o usuário ouvir,
  com o tempo de cada um.
- Frases com ✗: ouça antes de mexer.
- Silêncios > 1,5 s sem som, emendas de vogais, respiração no meio de número.

## Ao terminar

- `projeto.json`: `fase: "conferencia"` e, em `historico`, o que foi conferido e corrigido.
- Ao entregar, uma linha: o que foi conferido e o que depende do ouvido do usuário.
