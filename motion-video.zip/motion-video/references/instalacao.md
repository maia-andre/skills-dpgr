# Instalação do kit

O kit (`kit/` nesta skill) é um motor completo e pequeno: HTML + JS para as cenas, Python para narração,
render e conferência. Copie para a raiz do projeto do usuário (ou para uma pasta `video/` dentro dele).

## 1. Copiar

```bash
SKILL=<pasta desta skill>            # ex.: ~/.claude/skills/motion-video
cp -rn "$SKILL"/kit/{lib,render,tts,scripts,marca,requirements.txt} .
mkdir -p videos && cp -r "$SKILL"/kit/modelo videos/<nome>
```

`-n` não sobrescreve: se o projeto já tem algum desses arquivos, compare antes de substituir.

`.gitignore` sugerido:

```
.venv/
.env
modelos/
**/out/
**/audio/cache/
**/audio/*/cache/
**/referencias/
__pycache__/
```

(Deixe `audio/*.wav` e `timing.*` no git se quiser re-renderizar sem regenerar a voz; são pequenos.)

## 2. Ambiente Python (sempre venv)

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python -m playwright install chromium
```

Windows: `.venv\Scripts\pip` / `.venv\Scripts\python`. Python 3.11+.
**Nunca** `pip install` no Python do sistema, `--user` ou `sudo pip`.

## 3. ffmpeg

Precisa estar no PATH (`ffmpeg -version`). Debian/Ubuntu: `sudo apt install ffmpeg` (peça ao usuário
rodar; não use sudo sem permissão). macOS: `brew install ffmpeg`. Windows: `winget install ffmpeg`.

## 4. Modelos (só o que for usar)

```bash
.venv/bin/python scripts/baixar_modelos.py whisper   # conferência de pronúncia (~640 MB)
.venv/bin/python scripts/baixar_modelos.py kokoro    # voz local Kokoro (~340 MB)
.venv/bin/python scripts/baixar_modelos.py piper-dii # voz local Piper pt-BR (~110 MB)
```

Tudo de GitHub releases (vão para `modelos/`, fora do git; `TTS_MODELOS` muda a pasta).
Voz em nuvem (Fish): `FISH_API_KEY=...` num `.env` na raiz (fora do git).

## 5. Teste de fumaça (1 minuto)

```bash
.venv/bin/python -m tts.narrar videos/<nome> --provedor silencio
.venv/bin/python scripts/gerar_sons.py
.venv/bin/python render/render.py videos/<nome> --rascunho
.venv/bin/python render/conferir.py videos/<nome>
```

Deve terminar com "✓ Conferência OK" e um `out/rascunho.mp4` com o vídeo-modelo. Abra
`videos/<nome>/episodio.html` no navegador para a prévia interativa.

## Estrutura

```
lib/        motor.js (seek determinístico, prévia), componentes.js/.css
render/     render.py (Playwright → segmentos → ffmpeg), mix.py (trilha), conferir.py
tts/        narrar.py (CLI), pronuncia.py + pronuncia.json, conferencia_whisper.py, provedores/
scripts/    baixar_modelos.py, gerar_sons.py, trilha.py, fatiar_gravacao.py
marca/      marca.json, fontes/, sons/ (gerados)
videos/<nome>/  episodio.html · narracao.json · projeto.json · CLAUDE.md · briefing.md · roteiro.md
                audio/ (gerado) · out/ (gerado) · referencias/ · gravacao/
```
