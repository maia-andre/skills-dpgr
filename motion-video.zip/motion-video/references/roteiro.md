# Roteiro

## Estruturas prontas

Escolha uma com o usuário (ou proponha) e mantenha-a fixa se for série: o público aprende o ritmo.

**Didática em 5 blocos** (treinamento, tutorial, pílula de conceito; 3–5 min)
1. **Contexto**: uma situação real que dói ("o processo voltou com 6 apontamentos").
2. **Conceito**: a ideia em 2–3 passos.
3. **Exemplo**: um caso desenvolvido, com números e raciocínio na tela.
4. **Erro comum** ❌ → ✔: a frase errada aparece, é riscada, a certa entra.
5. **Para guardar**: uma frase sozinha na tela, com respiro curto preenchido por efeito; se for série,
   anuncia o próximo episódio.

**Lançamento / divulgação** (1,5–3 min)
gancho (o problema, sem rodeio) → o que é → como funciona (2–3 telas reais) → prova (números,
casos, quem já usa) → quem está por trás / princípios → chamada (endereço, QR, contato).

**Vitrine para convencer** (gestores, banca, financiador; 2–3 min)
desconforto proposital com dados (fatos, sem acusar pessoas) → pergunta → a solução em ação →
resultado medido → próximos passos e o que se pede.

**Explicativo** (conceito técnico ou histórico; 4–8 min)
pergunta que fisga → intuição com metáfora visual → mecanismo em camadas → exemplo concreto →
onde quebra / limites → retomada da pergunta.

**Sem narração** (redes, telão, vídeo de abertura)
a tela carrega todo o texto: frases de até ~8 palavras, uma por vez, tempo de leitura ≈ 0,3 s por palavra
+ 1 s; música mais alta (`--fundo-db -14`) e efeitos marcando as viradas.

## Formato do `roteiro.md`

```markdown
## b3 · Exemplo  (~35 s)
| # | Fala | Tela |
|---|---|---|
| 3.1 | Veja um caso real. Antes, eram seis horas por semana. | contador 0 → **6 h/semana** |
| 3.2 | Depois da mudança, vinte minutos. | segundo contador → **20 min**; rodapé "Valores ilustrativos" |
Fonte dos números: <arquivo, página, data>
```

O número da linha (3.2) é o `data-frase="b3.2"` da cena. Uma linha de tabela = uma frase da narração.
Se a tela precisa mudar no meio de uma frase longa, quebre a frase em duas.

## Redação para voz sintética

Regras aprendidas em produção (valem para voz humana também, em grau menor):

- **Frases curtas**, uma ideia por frase. Voz sintética perde a entonação em frase longa.
- **Número com frase própria**: "Trezentos e trinta e três veículos. Todas as secretarias." O número
  no meio de frase longa embola ou "come" dígitos. Código longo (147288) a voz lê correndo: evite na fala.
- **Concordância no feminino** ("trezentas e vinte cadeiras"): escreva por extenso no roteiro; o
  conversor de números usa o masculino.
- **Siglas**: raras → por extenso na fala, sigla na tela. Do dia a dia → sigla, e **aprovação de ouvido**.
  "IA" no meio de frase pode sair "iá": grafe "I.A.". Nome de sistema/produto difícil: teste 3–5 grafias.
- **Emenda de vogais** ("lê o", "zerou o", "amplia a") gera palavra fantasma: reescreva ou desacelere só
  aquela frase (`"velocidade": 0.85` na fala).
- **Construções que confundem**: "em comodato" virou "incomodado" → "cedido em regime de comodato".
- **Lei/norma**: carimbo em tela, nunca "artigo 6º, inciso XXIII" na fala.
- **Tom**: primeira pessoa, cordial, direto, sem jargão; mostra o caminho, não dá bronca.
- **Pergunta retórica** funciona bem em voz sintética para abrir ou virar bloco; teste 3–5 versões e
  deixe o usuário escolher de ouvido.
- Contexto institucional: nada de nomes de pessoas reais em casos fictícios; use cargo/unidade.

## `narracao.json`

```json
{
  "idioma": "pt",
  "voz": { "provedor": "kokoro", "voz": "pf_dora", "velocidade": 1.0 },
  "pausa_frase": 0.55, "tentativas": 8, "limiar": 0.85,
  "checar": ["palavras que precisam aparecer na transcrição"],
  "blocos": [
    { "id": "b1", "cena": "Contexto", "fala": "Parágrafo. Dividido em frases por ponto, interrogação e exclamação." },
    { "id": "b3", "cena": "Exemplo", "falas": [
      { "texto": "Eram seis horas por semana.", "expect": "Eram 6 horas por semana." },
      { "texto": "Uma frase que embola.", "velocidade": 0.85 },
      { "texto": "Para guardar: a frase final.", "pausa_depois": 1.6, "checar": ["guardar"] }
    ] }
  ]
}
```

- `fala` (parágrafo) é dividida sozinha; use `falas` quando precisar de `expect` (como o Whisper escreve
  números), `velocidade` própria, `pausa_depois` (segurar a tela) ou `checar` por frase.
- `voz.opcoes` passa parâmetros extras ao provedor (ex.: `{"modo": "free"}` no Fish).
- Mostre ao usuário as frases que você alterou em relação ao roteiro aprovado e por quê.
