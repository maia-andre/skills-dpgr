# Variantes, idiomas e validação

## Variantes por parâmetro na URL

Uma variante é o **mesmo `episodio.html`** com um parâmetro: `episodio.html?semlogos`. No render e na
conferência, `--query` (que entra no hash do cache de segmentos, então variantes não se misturam):

```js
const VAR = new URLSearchParams(location.search);
if (VAR.has('semlogos')) document.getElementById('faixa-logos').style.display = 'none';
```

```bash
.venv/bin/python render/render.py videos/<nome> --query semlogos --saida videos/<nome>/out/<nome>-sem-logos.mp4
RENDER_QUERY=semlogos .venv/bin/python render/conferir.py videos/<nome>
```

Variante que muda a **fala** (um caso a mais, por exemplo): um bloco de áudio alternativo (`b6` e `b6x`
no `narracao.json`) e a variante escolhe qual `Motor.cena` registrar. A trilha (`scripts/trilha.py
--query …`) e o plano seguem sozinhos. Combine parâmetros com `&` (`--query "lang=en&semlogos"`).

## Outros idiomas

- `narracao.<idioma>.json` com `"idioma": "en"` → `python -m tts.narrar videos/<nome> --idioma en` grava em
  `audio/en/`, troca o dicionário (`tts/pronuncia.en.json`), a expansão de números e o Whisper.
- Texto de tela em `textos.<idioma>.js`: `window.TEXTOS = { titulo, html: { '<seletor>': '<html>' | [html por ocorrência] } }`.
- No topo do episódio, antes do motor:

```html
<script>
const LANG = new URLSearchParams(location.search).get('lang') || 'pt';
const AUD = LANG === 'pt' ? 'audio/' : `audio/${LANG}/`;
document.documentElement.lang = { pt: 'pt-BR', en: 'en', es: 'es' }[LANG] || LANG;
document.write(`<script src="${AUD}timing.js"><\/script>` + (LANG === 'pt' ? '' : `<script src="textos.${LANG}.js"><\/script>`));
</script>
```

  e depois de montar o DOM: `Motor.config({ …, audio: AUD })` e aplique `TEXTOS.html` (seletor sem
  elemento deve **lançar erro**, para tradução órfã não passar calada). Listas montadas em JS leem o texto
  de `TEXTOS` também.
- Render/conferir/trilha com `--query "lang=en"`. O render pega o áudio de `audio/en/`.
- Tradução: a duração muda (espanhol costuma ser ~10% mais longo); as cenas se reajustam, mas olhe o mosaico.
- Nome sem tradução oficial: proponha e marque como decisão do revisor. Capturas de tela ficam no
  idioma original salvo pedido.
- Voz: a mesma voz pt lendo outro idioma soa com sotaque; pode ser aceitável (ou desejado). Se não, voz
  nativa daquele idioma. Deixe o revisor decidir de ouvido.

## Vertical (9:16)

`Motor.config({ largura: 1080, altura: 1920 })` numa cópia do episódio (`episodio-vertical.html`
reaproveitando o mesmo `audio/`) ou numa variante por query que troca as classes de layout. O render lê a
dimensão do próprio episódio. Reposicione tudo: margens, corpo de texto maior, uma coluna.

## Validação com terceiros

- Mande **trechos** do que mudou (`render.py --de 40 --ate 75 --saida out/validacao/1-mais-exemplos.mp4`),
  numerados, não o vídeo inteiro a cada rodada.
- Para revisor externo: uma página com os vídeos (540p bastam), o roteiro por cena (fala e tela, extraídos
  do próprio `narracao.json`/`textos.*.js`, nunca de cópia à mão), as **decisões em aberto como
  múltipla escolha** e um botão "copiar respostas" para colar no canal que ele usa. Respostas coladas
  voltam como lista de mudanças objetivas.
- A cada rodada, registre no `CLAUDE.md` do vídeo: pedido, de quem, o que mudou, duração nova.
- Antes do render final: reconfira números que mudam (site, painel) e recapture telas; se mudou fala,
  renarre só aqueles blocos (`--blocos`) e regenere a trilha.
- MP4 final fica fora do git. Publicar (release, upload, envio ao revisor) só com o ok do usuário.
