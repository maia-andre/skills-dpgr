# Cenas

O vídeo é uma **função pura do tempo**. `render.py` abre `episodio.html?render=1` num Chromium sem
cabeça e chama `seek(i/fps)` para cada quadro, em vários processos, em qualquer ordem.

## Esqueleto (`kit/modelo/episodio.html`)

```html
<link rel="stylesheet" href="../../lib/componentes.css">
<div id="palco"></div>
<script src="audio/timing.js"></script>
<script src="../../lib/motor.js"></script>
<script src="../../lib/componentes.js"></script>
<script>
Motor.config({ fps: 30, pad: 0.6 });            // vertical: { largura: 1080, altura: 1920 }
Motor.cena('b1', { montar(el, T) {…}, quadro(t, ctx, T) {…} });
…
Motor.iniciar();
</script>
```

## Estilo A — uma cena por bloco (`Motor.cena`)

```js
Motor.cena('b3', {
  extra: 0,                         // segundos além de áudio + pad (respiro do fim)
  montar(el, T) {                   // DOM UMA vez; devolve o contexto
    const card = C.cartaoCaso({ caso: 'a', rotulo: 'Caso', titulo: '"30 impressoras"', linhas: ['<b>7+ anos</b> de uso'] });
    card.dataset.frase = 'b3.1';    // liga o elemento à frase 1 do bloco (conferência)
    el.append(card);
    return { card };
  },
  quadro(t, c, T) {                 // t = segundos desde o início da cena (= início do áudio do bloco)
    A.entrar(c.card, T.p(t, T.frase(0), 0.6));
  },
});
```

- `T.frase(i)` → início da frase i (**0-based**) do bloco. `data-frase="bN.K"` usa K **1-based**.
- `T.p(t, inicio, dur, ease)` → progresso 0..1. Eases: `A.saida` (padrão), `A.entradaSaida`, `A.volta`
  (leve pulo), `A.lin`. `T.fim` = duração da cena.
- Helpers: `A.entrar(el,k,{x,y,escala})`, `A.sair(el,k)`, `A.palavras(el,k)` (palavra a palavra — **achata
  o HTML interno**, não use `<em>` dentro), `A.contar(el,k,de,ate,{casas,prefixo,sufixo})` (formato pt-BR),
  `A.mix(a,b,k)`, `A.clamp`.

## Estilo B — timeline única com GSAP pausado

Bom para vídeos com muitas camadas, transições entre blocos e 3D. As cenas são declaradas vazias só para
o plano; a timeline é dirigida pelo motor:

```js
['b1','b2','b3'].forEach((b) => Motor.cena(b, {}));
Motor.cena('b4', { extra: 2.5 });
const at = (id) => Motor.frase(id).t0, fim = (id) => Motor.frase(id).fim;   // tempo GLOBAL
const tl = gsap.timeline({ paused: true, defaults: { ease: 'power3.out' } });
tl.fromTo('#titulo', { y: 36, opacity: 0 }, { y: 0, opacity: 1, duration: .55 }, at('b1.2'));
Motor.efeito('acerto', fim('b3.2') + .05, -20);
Motor.aoQuadro = (t) => tl.seek(Math.min(t, tl.duration()), false);
Motor.iniciar();
```

- GSAP **local** (`lib/vendor/gsap-<versão>.min.js`, baixado do npm/cdnjs uma vez), nunca do CDN na cena.
- Timeline **sempre pausada**; nada de `gsap.to` solto, `repeat: -1` ou `delay` fora da timeline.
- Estado derivado (qual peça está acesa, contadores): proxies `{v: 0}` tweenados na timeline e aplicados
  no `onUpdate`, que é função de t.
- Elementos com `data-frase` continuam valendo para a conferência.
- 3D em CSS (`preserve-3d`): ponha a opacidade nas faces, não no contêiner (opacidade < 1 no pai achata).

## Componentes (`lib/componentes.js` + `.css`)

| Componente | Uso | Animação |
|---|---|---|
| `C.titulo(texto, sub)` | abertura | `A.entrar` |
| `.frase-grande` (CSS) | tipografia cinética; `<em>` em destaque | `A.entrar` / `A.palavras` |
| `C.trilha(nos, {rotulo})` | barra de progresso de etapas/capítulos | `C.trilhaQuadro(el, {acesos, atual, k})` |
| `C.cartaoCaso({caso, rotulo, titulo, linhas})` | caso condutor; cor em `--caso-<nome>` | `A.entrar` |
| `C.erroCerto(errado, certo)` | ❌ → ✔ | `C.erroCertoQuadro(el, kErro, kRisco, kCerto)` |
| `C.guardar(frase)` | frase final sozinha | `A.palavras` no `<p>` |
| `C.carimbo(texto)` | base legal / referência em chip | `A.entrar(…, {escala: 1.4})` |
| `C.narrador({sigla, nome, placeholder})` | badge do narrador/personagem | `A.entrar` |
| `C.tabela(colunas, linhas)` | comparação | `C.tabelaQuadro(el, k, {coluna, kDestaque})` |
| `C.rodape(texto)` | "Valores ilustrativos", fonte, data | — |
| `C.h(html)`, `C.esc(s)` | utilitários | — |

Componente usado em mais de um vídeo → `lib/`. Específico → `<style>`/`<script>` no próprio `episodio.html`.
Prefixe classes específicas do vídeo (classes genéricas como `.eu` colidem com estilos de outro vídeo copiado).

## Recursos visuais que funcionaram

- **Telas reais de sistema/site**: captura em alta (Playwright, página inteira), recortada e animada
  (zoom, realce de área, cursor desenhado). Recapture antes do render final.
- **Réplica de tela em HTML** quando a captura não serve (dados fictícios, usuário fictício).
- **Mapas**: SVG com `pathLength="1"` + `stroke-dashoffset` função de t para "desenhar" contornos.
- **Números**: contador (`A.contar`) com o valor exato na tela; rodapé com fonte e data da coleta.
- **Simulações/visualizações**: quadros reais gerados por script (semente fixa) e desenhados por índice de t
  (`Math.floor(t * fps)`), nunca gravação de tela. GIF → PNGs com `ffmpeg -vsync 0`.
- **Canvas** (chuva de caracteres, partículas): desenhe tudo a partir de t e de um PRNG com semente; nunca
  acumule estado entre quadros.
- **Recorte de fundo de imagem** sem PIL/ImageMagick: canvas dentro do próprio Playwright.
- **QR code**: gere localmente como SVG; teste com um celular antes da entrega.

## Linguagem visual

- Uma ideia por vez; o que sai, sai **antes** do próximo entrar.
- Margens laterais ≥ 160 px (16:9) / ≥ 80 px (9:16). Corpo mínimo 26 px em 1080p. Títulos não colados
  no topo (≥ 120 px): revisores notam.
- Fundo escuro + um destaque é um padrão seguro; cor por caso/tema ajuda a seguir histórias paralelas.
  Uma cor de fundo por bloco ajuda a marcar capítulos.
- Logos de parceiros: equilibre pelo **peso visual**, não pela altura igual (ajuste altura por peça).
- Identidade de terceiros: use a deles (cores, fonte, mascote) e nada da sua.
- Fontes em `marca/fontes/` com `@font-face` local. O motor espera `document.fonts.ready` antes do primeiro quadro.
- Vertical (9:16) é outro layout, não o 16:9 encolhido: reposicione; o áudio é o mesmo.

## Proibido (quebra o determinismo ou o render)

- CSS `transition`/`animation`, `requestAnimationFrame`, `setTimeout`/`setInterval`, `Date.now()`,
  `Math.random()` sem semente dentro de `quadro`.
- Estado acumulado entre quadros (contadores incrementais, "se já mostrou, não mostra de novo").
- Recurso da internet (fonte, imagem, script de CDN): o render pode estar offline e o resultado muda.
- Registrar `Motor.efeito` dentro de `quadro` (duplica a cada quadro): registre uma vez, fora.
- Duplicar offsets de tempo (PAD, extra) em outro arquivo: a fonte única é `Motor.plano()`.
