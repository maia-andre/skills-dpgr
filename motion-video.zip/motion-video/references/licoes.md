# Lições que custaram caro

Saíram de uma série de treinamento (11 episódios), quatro vídeos de lançamento (um deles em três
idiomas, validado por uma instituição parceira) e uma série pessoal de 7 vídeos, todos com este motor.

## Processo
1. **Narração primeiro.** Animar antes da voz é refazer tudo quando a voz chega. Sem voz decidida, use
   `--provedor silencio` e anime sobre a duração estimada.
2. **Briefing aprovado antes de roteiro; roteiro aprovado antes de narrar.** Cada etapa pulada volta
   como retrabalho triplicado (fala → cena → conferência).
3. **Uma fonte de tempo.** Um script de música que copiou `PAD` e `extra` do HTML ficou dessincronizado
   na primeira mudança. Tudo lê `Motor.plano()`.
4. **Uma fonte de texto.** Página de revisão e roteiro traduzido gerados **a partir** dos arquivos do
   vídeo; cópia à mão fica para trás na primeira rodada.
5. **Trechos para validação**, não o vídeo inteiro. Revisor responde mais rápido e com mais precisão.
6. **Reconferir dado vivo antes de cada render final.** Contadores de site mudaram três vezes no mesmo
   dia de entrega.
7. **Registrar decisões no `CLAUDE.md` do vídeo** (com data e quem pediu). Sessões futuras retomam dali.
8. **Conferência sempre**, inclusive "só mudei uma palavra": a palavra muda a duração do bloco.

## Roteiro
9. **Texto em tela ≠ transcrição.** Tela cheia de texto compete com a voz.
10. **Caso citado ganha exemplo desenvolvido.** "Escolheu o mais barato" sem mostrar a comparação
    soou vazio ao lado de um caso com números e raciocínio.
11. **Números exatos na tela, arredondados na fala.** "Seiscentos e cinquenta e oito" é lido; "658"
    na tela é visto.
12. **Lei como carimbo.** Ler "artigo, inciso, alínea" mata o ritmo.
13. **Pessoas fictícias como cargo/unidade.** Nome inventado ou trocadilho ofende quem assiste e faz
    aquele trabalho de verdade.
14. **Fatos sem acusar pessoas.** Abrir com um dado desconfortável funciona para convencer; apontar
    culpados não.
15. **Personagem/mascote/voz de terceiros só com autorização.** Até lá, placeholder visível ("arte provisória").
16. **Iniciativa de terceiros usa a identidade deles**, sem a sua marca e sem puxar o assunto para você.

## Voz
17. **O ASR não ouve siglas.** Aprovação de sigla é de ouvido, sempre.
18. **Grafia fonética "esperta" piora** com frequência. Teste antes de registrar.
19. **Normalização de números do serviço de voz pode estragar valores.** Desligue e expanda localmente.
20. **Emenda de vogais** ("lê o", "zerou o") e **número em frase longa** são os defeitos recorrentes
    de voz sintética boa: reescreva a frase ou desacelere só ela.
21. **Vozes "idosas" de biblioteca soam cômicas.** Credibilidade vem de ritmo e dicção, não de idade.
22. **Velocidade natural > desacelerada.** A 0,85 a voz boa perde a naturalidade; desacelere pontualmente.
23. **Clones de personagem/dublagem e de pessoas reais: fora**, mesmo que estejam na biblioteca pública.

## Áudio
24. **Silêncio mudo > ~1,5 s soa como defeito.** Respiro curto + efeito leve.
25. **Efeito pontual, não em todo lugar.**
26. **Música de terceiros tem direitos** (inclusive trilha famosa "só de fundo"). Sintetize.
27. **Vídeo sem voz:** música ~10 dB mais alta.

## Cenas e render
28. **Determinismo ou nada.** Um `setTimeout` esquecido gera quadros diferentes em cada processo.
29. **Nada da internet no render.** Fonte do Google que não carregou = vídeo com fonte errada sem erro.
30. **`palavras()` achata o HTML** do elemento: destaque some.
31. **Classes genéricas colidem** ao copiar estilos entre vídeos: prefixe.
32. **Opacidade no contêiner 3D achata o `preserve-3d`**: ponha nas faces.
33. **Simulação entra como quadros reais desenhados por t**, nunca gravação de tela (não é determinística
    e fica borrada).
34. **Falsos positivos da conferência** (clip-path, entrada no meio da frase): confirme no quadro e anote.
35. **Logos com altura igual não têm peso igual.** Ajuste por peça.
36. **Margem no topo**: título colado na borda foi o primeiro comentário de um revisor.
37. **Trecho 100% mudo** quebrava o encoder de áudio (loudnorm + AAC); o mix agora põe piso de ruído inaudível.

## Ambiente
38. **Redes corporativas** costumam bloquear Hugging Face e TTS em nuvem; GitHub e PyPI costumam passar.
    Prefira pesos de GitHub releases. Se um download falhar por bloqueio, avise; não contorne.
39. **Python só no venv do projeto.** Nada de `pip` no sistema ou `--user`.
40. **Vídeos, áudio gerado e pesos de modelos fora do git** (`out/`, `audio/cache/`, `modelos/`).
41. **Legenda:** se a plataforma gera (YouTube), não gaste tempo com `.srt` sem pedido.
