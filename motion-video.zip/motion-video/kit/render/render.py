"""Renderiza um episódio: episodio.html (Motor.seek) → frames → MP4 com a trilha mixada.

  python render/render.py videos/meu-video                  # 1920×1080, fps do vídeo
  python render/render.py videos/meu-video --rascunho       # 960×540 a 15 fps, rápido para revisar
  python render/render.py videos/meu-video --de 10 --ate 25 # só um trecho (prévia de cena)
  python render/render.py videos/meu-video --workers 6
  python render/render.py videos/meu-video --query semlogos # variante: parâmetro extra na URL
  python render/render.py videos/meu-video --fundo videos/meu-video/audio/trilha.wav --ducking 6

Paralelo e retomável: o vídeo é dividido em segmentos renderizados por processos independentes e
guardados em out/segmentos/<hash>/. O hash cobre o HTML, o timing e a lib — mudou algo, re-renderiza.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
from render.mix import montar_trilha  # noqa: E402

LARG, ALT = 1920, 1080  # padrão; o vídeo pode mudar com Motor.config({ largura, altura }) (ex.: 1080×1920)


def url(ep: Path) -> str:
    q = os.environ.get("RENDER_QUERY", "")  # definido por --query; os processos filhos herdam
    return (ep / "episodio.html").resolve().as_uri() + "?render=1" + (f"&{q}" if q else "")


def dimensoes() -> tuple[int, int]:
    """Tamanho do quadro, lido do episódio por ler_plano() e passado aos processos filhos pelo ambiente."""
    w, h = os.environ.get("RENDER_DIM", f"{LARG}x{ALT}").split("x")
    return int(w), int(h)


def abrir(pw, ep: Path):
    nav = pw.chromium.launch(args=["--allow-file-access-from-files", "--autoplay-policy=no-user-gesture-required"])
    largura, altura = dimensoes()
    pag = nav.new_page(viewport={"width": largura, "height": altura})
    erros = []
    pag.on("pageerror", lambda e: erros.append(str(e)))
    pag.goto(url(ep))
    pag.wait_for_function("window.MOTOR_PRONTO === true", timeout=30000)
    if erros:
        raise RuntimeError("Erro de JavaScript no episódio: " + " | ".join(erros))
    return nav, pag


def ler_plano(ep: Path) -> tuple[list[dict], int, list[dict]]:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        nav, pag = abrir(pw, ep)
        plano, fps, efeitos, dim = pag.evaluate("[Motor.plano(), Motor.fps, window.EFEITOS || [], [Motor.largura, Motor.altura]]")
        nav.close()
    os.environ["RENDER_DIM"] = f"{dim[0]}x{dim[1]}"
    return plano, fps, efeitos


def segmento(args) -> str:
    ep, i0, i1, fps, destino, escala = args
    from playwright.sync_api import sync_playwright
    largura, altura = dimensoes()
    w, h = (largura, altura) if escala == 1 else (int(largura * escala) // 2 * 2, int(altura * escala) // 2 * 2)
    tmp = destino.with_suffix(".tmp.mp4")
    ff = subprocess.Popen(
        ["ffmpeg", "-v", "error", "-y", "-f", "image2pipe", "-framerate", str(fps), "-c:v", "mjpeg", "-i", "-",
         "-vf", f"scale={w}:{h}:flags=lanczos", "-c:v", "libx264", "-preset", "medium",
         "-crf", "18" if escala == 1 else "26", "-pix_fmt", "yuv420p", "-r", str(fps), str(tmp)],
        stdin=subprocess.PIPE)
    with sync_playwright() as pw:
        nav, pag = abrir(pw, ep)
        for i in range(i0, i1):
            pag.evaluate(f"seek({i / fps})")
            ff.stdin.write(pag.screenshot(type="jpeg", quality=92))
        nav.close()
    ff.stdin.close()
    if ff.wait() != 0:
        raise RuntimeError(f"ffmpeg falhou no segmento {i0}-{i1}")
    tmp.rename(destino)
    return destino.name


def pasta_audio(ep: Path) -> Path:
    """audio/ ou, com lang=xx na --query (versão em outro idioma), audio/xx/."""
    from urllib.parse import parse_qs
    lang = parse_qs(os.environ.get("RENDER_QUERY", "")).get("lang", ["pt"])[0]
    return ep / "audio" if lang == "pt" else ep / "audio" / lang


def assinatura(ep: Path, extra: str) -> str:
    h = hashlib.sha1(extra.encode())
    for arq in [ep / "episodio.html", *sorted(ep.glob("textos.*.js")), pasta_audio(ep) / "timing.json", *sorted(p for d in ("lib", "marca") for p in (RAIZ / d).rglob("*") if p.is_file())]:
        if arq.exists():
            h.update(arq.read_bytes())
    return h.hexdigest()[:12]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("episodio", type=Path)
    p.add_argument("--rascunho", action="store_true")
    p.add_argument("--de", type=float, default=0.0)
    p.add_argument("--ate", type=float)
    p.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 2))
    p.add_argument("--fundo", type=Path, help="música de fundo (opcional)")
    p.add_argument("--fundo-db", type=float, default=-24.0, help="volume da música (padrão -24 dB; sem voz, ~-14)")
    p.add_argument("--ducking", type=float, default=0.0, help="dB a abaixar a música sob a voz (ex.: 6)")
    p.add_argument("--saida", type=Path)
    p.add_argument("--query", default="", help="parâmetros extras na URL do episódio (variantes), ex.: semlogos")
    a = p.parse_args()
    os.environ["RENDER_QUERY"] = a.query
    ep = a.episodio.resolve()
    out = ep / "out"
    out.mkdir(exist_ok=True)

    t0 = time.time()
    plano, fps, efeitos = ler_plano(ep)
    escala = 0.5 if a.rascunho else 1
    if a.rascunho:
        fps = 15
    total = plano[-1]["inicio"] + plano[-1]["dur"]
    ini, fim = a.de, min(a.ate or total, total)
    f0, f1 = int(round(ini * fps)), int(math.ceil(fim * fps))
    (out / "plano.json").write_text(json.dumps(plano, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Plano: {len(plano)} cenas, {total:.2f} s · render {ini:.1f}–{fim:.1f} s = {f1 - f0} quadros a {fps} fps")

    sig = assinatura(ep, f"{fps}|{escala}|{a.query}")
    pasta_seg = out / "segmentos" / sig
    pasta_seg.mkdir(parents=True, exist_ok=True)
    n = max(1, min(a.workers * 2, (f1 - f0) // fps or 1))
    passo = math.ceil((f1 - f0) / n)
    tarefas = []
    for k in range(n):
        i0, i1 = f0 + k * passo, min(f1, f0 + (k + 1) * passo)
        if i0 >= i1:
            continue
        dest = pasta_seg / f"seg_{i0:06d}_{i1:06d}.mp4"
        if not dest.exists():
            tarefas.append((ep, i0, i1, fps, dest, escala))
    print(f"Segmentos: {n} ({n - len(tarefas)} reaproveitados) · {a.workers} processos")
    if tarefas:
        with ProcessPoolExecutor(max_workers=a.workers) as ex:
            for nome in ex.map(segmento, tarefas):
                print(f"  ✓ {nome}")

    segs = sorted(s for s in pasta_seg.glob("seg_*.mp4")
                  if f0 <= int(s.stem.split("_")[1]) < f1)
    lista = out / "segmentos.txt"
    lista.write_text("".join(f"file '{s.as_posix()}'\n" for s in segs), encoding="utf-8")
    video = out / "video_mudo.mp4"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lista), "-c", "copy",
                    str(video)], check=True)

    trilha = montar_trilha(ep, plano, out / "trilha.wav", a.fundo, a.fundo_db, efeitos=efeitos, ducking_db=a.ducking)
    nome = a.saida or out / (("rascunho" if a.rascunho else ep.name) + ("" if ini == 0 and fim == total else f"_{ini:g}-{fim:g}s") + ".mp4")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(video), "-ss", f"{ini}", "-t", f"{fim - ini}", "-i", str(trilha),
                    "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                    "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "48000", "-c:a", "aac", "-b:a", "192k",
                    "-shortest", str(nome)], check=True)
    video.unlink(missing_ok=True)
    # limpa segmentos de versões antigas
    for velho in (out / "segmentos").iterdir():
        if velho.is_dir() and velho.name != sig:
            shutil.rmtree(velho, ignore_errors=True)
    print(f"\nPronto: {nome} ({fim - ini:.1f} s) em {time.time() - t0:.0f} s")


if __name__ == "__main__":
    main()
