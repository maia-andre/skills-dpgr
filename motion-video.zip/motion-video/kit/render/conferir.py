"""Conferência antes de entregar.

1. Sincronia (no HTML, sem precisar do MP4): todo elemento com data-frase="bN.K" deve estar
   INVISÍVEL 0,25 s antes do início da frase K do bloco bN e VISÍVEL 0,9 s depois.
   Também avisa se o elemento sai da área do quadro (Motor.largura × Motor.altura).
2. MP4 (se existir em out/): duração bate com o plano, tem faixa de áudio, e extrai um frame
   em cada frase-chave para out/conferencia/ + um mosaico (mosaico.jpg) para olhar de uma vez.
3. Relatório de pronúncia da narração (audio/relatorio.json), se houver.

  python render/conferir.py series/_modelo
Sai com código 1 se houver falha.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
from render.render import abrir, pasta_audio  # noqa: E402

JS_OPAC = """(sel) => {
  const el = document.querySelector(sel); if (!el) return null;
  let o = 1, n = el;
  while (n && n !== document.body) {
    const cs = getComputedStyle(n);
    if (cs.display === 'none' || cs.visibility === 'hidden') return {o: 0, fora: false};
    o *= parseFloat(cs.opacity); n = n.parentElement;
  }
  const r = el.getBoundingClientRect();
  return {o, fora: r.left < -2 || r.top < -2 || r.right > Motor.largura + 2 || r.bottom > Motor.altura + 2};
}"""


def sincronia(ep: Path):
    from playwright.sync_api import sync_playwright
    falhas, marcas = [], []
    with sync_playwright() as pw:
        nav, pag = abrir(pw, ep)
        plano = {c["bloco"]: c for c in pag.evaluate("Motor.plano()")}
        timing = pag.evaluate("window.TIMING || {}")
        chaves = pag.evaluate("[...document.querySelectorAll('[data-frase]')].map(e => e.dataset.frase)")
        for ch in chaves:
            bloco, k = ch.split(".")
            frases = timing.get(bloco, {}).get("frases", [])
            if bloco not in plano or int(k) > len(frases):
                falhas.append(f"{ch}: bloco/frase inexistente no timing")
                continue
            t = plano[bloco]["inicio"] + frases[int(k) - 1]["t"]
            sel = f'[data-frase="{ch}"]'
            pag.evaluate(f"seek({max(0, t - 0.25)})")
            antes = pag.evaluate(JS_OPAC, sel)
            pag.evaluate(f"seek({t + 0.9})")
            depois = pag.evaluate(JS_OPAC, sel)
            ok = antes["o"] < 0.3 and depois["o"] > 0.7
            if int(k) == 1 and frases[0]["t"] < 0.3:
                ok = depois["o"] > 0.7  # primeira frase do bloco: não há "antes" dentro da cena
            linha = f"{'✓' if ok else '✗'} {ch:<6} t={t:6.2f}s  opac. antes {antes['o']:.2f} → depois {depois['o']:.2f}  «{frases[int(k) - 1]['texto'][:50]}»"
            if depois["fora"]:
                linha += "  ⚠ sai do quadro"
            print(linha)
            if not ok:
                falhas.append(ch)
            marcas.append({"chave": ch, "t": t + 0.9, "texto": frases[int(k) - 1]["texto"]})
        nav.close()
    return falhas, marcas, plano


def mp4(ep: Path, marcas, plano):
    vids = sorted((ep / "out").glob("*.mp4"), key=lambda p: p.stat().st_mtime) if (ep / "out").exists() else []
    vids = [v for v in vids if not v.name.startswith(("video_mudo", "seg_"))]
    if not vids:
        print("(sem MP4 em out/ — rode o render para conferir o vídeo)")
        return []
    v = vids[-1]
    info = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type",
                                      "-of", "json", str(v)], capture_output=True, text=True).stdout)
    dur = float(info["format"]["duration"])
    total = max(c["inicio"] + c["dur"] for c in plano.values())
    tipos = {s["codec_type"] for s in info.get("streams", [])}
    falhas = []
    print(f"\nMP4: {v.name} · {dur:.2f} s (plano {total:.2f} s) · faixas: {', '.join(sorted(tipos))}")
    if "audio" not in tipos:
        falhas.append("MP4 sem áudio")
    if v.stem == ep.name and abs(dur - total) > 0.2:
        falhas.append(f"duração do MP4 difere do plano ({dur:.2f} × {total:.2f})")
    pasta = ep / "out" / "conferencia"
    pasta.mkdir(parents=True, exist_ok=True)
    for f in pasta.glob("*.jpg"):
        f.unlink()
    for i, m in enumerate(marcas):
        if m["t"] < dur:
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{m['t']:.3f}", "-i", str(v), "-frames:v", "1",
                            "-q:v", "3", str(pasta / f"f_{i:03d}.jpg")], check=True)
    n = len(list(pasta.glob("f_*.jpg")))
    if n:
        cols = 3
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(pasta / "f_%03d.jpg"), "-vf",
                        f"scale=640:-1,tile={cols}x{-(-n // cols)}:padding=6:color=black", "-frames:v", "1",
                        str(pasta / "mosaico.jpg")], check=True)
        (pasta / "legenda.txt").write_text(
            "".join(f"f_{i:03d}  {m['chave']}  {m['texto']}\n" for i, m in enumerate(marcas)), encoding="utf-8")
        print(f"Frames-chave: {n} em {pasta.relative_to(ep)}/ (mosaico.jpg + legenda.txt) — OLHE o mosaico.")
    return falhas


def pronuncia(ep: Path):
    rel = pasta_audio(ep) / "relatorio.json"
    if not rel.exists():
        return []
    itens = json.loads(rel.read_text(encoding="utf-8"))
    ruins = [f"{i['bloco']}.{i['frase']}" for i in itens if i.get("ok") is False]
    conferidos = [i for i in itens if i.get("ok") is not None]
    print(f"\nPronúncia: {len(conferidos) - len(ruins)}/{len(conferidos)} frases aprovadas pelo Whisper"
          + (f" · reprovadas: {', '.join(ruins)}" if ruins else ""))
    if not conferidos:
        print("  (narração sem conferência — voz 'silencio' ou Whisper ausente)")
    return ruins


def main():
    ep = Path(sys.argv[1]).resolve()
    print("Sincronia (frases-chave):")
    falhas, marcas, plano = sincronia(ep)
    falhas += mp4(ep, marcas, plano)
    falhas += pronuncia(ep)
    print("\n" + ("✓ Conferência OK" if not falhas else f"✗ {len(falhas)} problema(s): {', '.join(map(str, falhas))}"))
    sys.exit(1 if falhas else 0)


if __name__ == "__main__":
    main()
