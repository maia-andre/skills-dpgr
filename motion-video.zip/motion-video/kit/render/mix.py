"""Monta a trilha de áudio do episódio a partir do plano do motor (Motor.plano()).

Cada bloco começa exatamente no `inicio` da sua cena — a mesma conta que o HTML usa.
Uso direto (normalmente é chamado pelo render.py):
  python render/mix.py series/_modelo out/plano.json
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

SR = 48000


def decodificar(arq: Path, sr: int = SR) -> np.ndarray:
    """Qualquer áudio → float32 mono na taxa `sr` (via ffmpeg)."""
    out = subprocess.run(["ffmpeg", "-v", "error", "-i", str(arq), "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"],
                         check=True, capture_output=True).stdout
    return np.frombuffer(out, dtype=np.float32)


SONS = Path(__file__).resolve().parents[1] / "marca" / "sons"


def montar_trilha(ep: Path, plano: list[dict], saida: Path, fundo: Path | None = None, fundo_db: float = -24.0,
                  efeitos: list[dict] | None = None, ducking_db: float = 0.0):
    """efeitos: [{"som": "guardar", "t": 81.2, "db": -14}] vindos do episódio (window.EFEITOS); sons em marca/sons/."""
    total = plano[-1]["inicio"] + plano[-1]["dur"]
    trilha = np.zeros(int(round(total * SR)) + 1, dtype=np.float32)
    for c in plano:
        arq = ep / c["audio"]
        if not arq.exists():
            print(f"! sem áudio para {c['bloco']} ({arq}) — trecho fica em silêncio")
            continue
        a = decodificar(arq)
        i = int(round(c["inicio"] * SR))
        n = min(len(a), len(trilha) - i, int(c["dur"] * SR))
        trilha[i:i + n] += a[:n]
    for ef in efeitos or []:
        arq = SONS / f"{ef['som']}.wav"
        if not arq.exists():
            print(f"! efeito sem arquivo: {arq.name} (rode python scripts/gerar_sons.py)")
            continue
        a = decodificar(arq) * (10 ** (ef.get("db", -14.0) / 20))
        i = int(round(ef["t"] * SR))
        n = min(len(a), len(trilha) - i)
        if n > 0:
            trilha[i:i + n] += a[:n]
    if fundo and fundo.exists():
        f = decodificar(fundo)
        f = np.tile(f, int(np.ceil(len(trilha) / max(len(f), 1))))[: len(trilha)]
        ganho = np.full(len(trilha), 10 ** (fundo_db / 20), dtype=np.float32)
        if ducking_db > 0:  # abaixa a música enquanto há voz, com subida/descida suave (~0,4 s)
            w = int(0.05 * SR)
            env = np.sqrt(np.convolve(trilha ** 2, np.ones(w) / w, "same"))
            voz = (env > 0.01).astype(np.float32)
            suave = int(0.4 * SR)
            voz = np.convolve(voz, np.ones(suave) / suave, "same")
            ganho *= 10 ** (-ducking_db * np.clip(voz * 2, 0, 1) / 20)
        trilha += f * ganho
    # piso de ruído a -100 dB (inaudível): trecho 100% mudo faz o loudnorm + AAC falharem no render
    trilha += np.random.default_rng(0).normal(0, 1e-5, len(trilha)).astype(np.float32)
    pico = np.max(np.abs(trilha)) if len(trilha) else 0
    if pico > 0.99:
        trilha *= 0.99 / pico
    saida.parent.mkdir(parents=True, exist_ok=True)
    sf.write(saida, trilha, SR)
    return saida


if __name__ == "__main__":
    ep, plano = Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
    print(montar_trilha(ep, plano, ep / "out" / "trilha.wav"))
