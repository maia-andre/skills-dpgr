"""Confere cada frase sintetizada transcrevendo com Whisper e comparando com o roteiro.

Sem prompt de vocabulário de propósito: o prompt "corrigiria" a grafia e esconderia o erro de pronúncia.

Dois motores, escolhidos automaticamente (ou por env CONFERENCIA_ASR=sherpa|openai):
  - sherpa (preferido): Whisper small em ONNX via sherpa-onnx, pesos do GITHUB releases
      python scripts/baixar_modelos.py whisper   → modelos/sherpa-onnx-whisper-small/
  - openai: pacote openai-whisper; pesos de openaipublic.azureedge.net (pode estar bloqueado).
"""
from __future__ import annotations

import difflib
import os
import sys
from functools import lru_cache

import numpy as np

from . import pronuncia
from .provedores.base import MODELOS

LIMIAR_PADRAO = 0.85


class _Sherpa:
    def __init__(self, pasta, idioma):
        import sherpa_onnx
        tam = pasta.name.rsplit("-", 1)[-1]
        self.rec = sherpa_onnx.OfflineRecognizer.from_whisper(
            encoder=str(pasta / f"{tam}-encoder.int8.onnx"), decoder=str(pasta / f"{tam}-decoder.int8.onnx"),
            tokens=str(pasta / f"{tam}-tokens.txt"), language=idioma, task="transcribe", num_threads=4)

    def __call__(self, a16):
        s = self.rec.create_stream()
        s.accept_waveform(16000, a16)
        self.rec.decode_stream(s)
        return s.result.text


class _OpenAI:
    def __init__(self, idioma):
        self.idioma = idioma
        import whisper
        self.m = whisper.load_model(os.environ.get("WHISPER_MODELO", "small"))

    def __call__(self, a16):
        return self.m.transcribe(a16, language=self.idioma, temperature=0.0, fp16=False,
                                 condition_on_previous_text=False)["text"]


def _modelo():
    return _modelo_de(pronuncia.IDIOMA)


@lru_cache(maxsize=None)
def _modelo_de(idioma: str):
    escolha = os.environ.get("CONFERENCIA_ASR", "auto")
    pasta = next(iter(sorted(MODELOS.glob("sherpa-onnx-whisper-*"))), None)
    if escolha in ("auto", "sherpa") and pasta:
        try:
            return _Sherpa(pasta, idioma)
        except Exception as e:  # noqa: BLE001
            print(f"! ASR sherpa indisponível: {e}", file=sys.stderr)
    if escolha in ("auto", "openai"):
        try:
            return _OpenAI(idioma)
        except Exception as e:  # noqa: BLE001 — pacote ausente ou download bloqueado
            print(f"! Whisper (openai) indisponível: {type(e).__name__}: {str(e)[:120]}", file=sys.stderr)
    return None


def disponivel() -> bool:
    return _modelo() is not None


def _para_16k(audio: np.ndarray, sr: int) -> np.ndarray:
    if sr == 16000:
        return audio.astype(np.float32)
    n = int(len(audio) * 16000 / sr)
    return np.interp(np.linspace(0, len(audio) - 1, n), np.arange(len(audio)), audio).astype(np.float32)


def transcrever(audio: np.ndarray, sr: int) -> str:
    m = _modelo()
    if m is None:
        raise RuntimeError("Sem ASR: python scripts/baixar_modelos.py whisper")
    return m(_para_16k(audio, sr)).strip()


def avaliar(esperado: str | list[str], transcricao: str, criticas: list[str] | None = None,
            limiar: float = LIMIAR_PADRAO) -> dict:
    """Compara roteiro × transcrição. `esperado` pode ser uma lista de formas aceitas (texto, expect)."""
    formas = [esperado] if isinstance(esperado, str) else esperado
    obtido = " ".join(pronuncia.para_comparar(transcricao))
    # equivalências aprovadas de ouvido (ex.: ASR escreve "ATP" quando a voz diz a sigla "ETP")
    for canon, alts in pronuncia.carregar().get("equivalentes_asr", {}).items():
        if canon.startswith("_"):
            continue
        c = " ".join(pronuncia.para_comparar(canon))
        for alt in alts:
            obtido = f" {obtido} ".replace(f" {' '.join(pronuncia.para_comparar(alt))} ", f" {c} ").strip()
    obtido = obtido.split()
    nota = max(difflib.SequenceMatcher(None, pronuncia.para_comparar(f), obtido).ratio() for f in formas)
    faltando = []
    texto_base = " ".join(pronuncia.para_comparar(formas[0]))
    obtido_txt = " " + " ".join(obtido) + " "
    for c in criticas or []:
        cc = " ".join(pronuncia.para_comparar(c))
        if cc and f" {cc} " in f" {texto_base} " and f" {cc} " not in obtido_txt:
            faltando.append(c)
    return {"ok": nota >= limiar and not faltando, "nota": round(nota, 3),
            "faltando": faltando, "transcricao": transcricao}
