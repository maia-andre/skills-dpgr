"""Kokoro v1.0 via kokoro-onnx, CPU. Vozes pt-BR: pm_alex (masculina), pf_dora (feminina);
en: af_heart, am_michael…; es: ef_dora, em_alex. O idioma vem do "idioma" do narracao.json.

Pesos: python scripts/baixar_modelos.py kokoro
       (GitHub releases thewh1teagle/kokoro-onnx, model-files-v1.0 → modelos/kokoro/)

Fonemas: trechos listados em pronuncia.json["fonemas"]["kokoro"] (ex.: sigla soletrada → ˈe tˈe pˈe) entram
como fonemas IPA; o resto do texto é fonemizado pelo próprio kokoro-onnx (espeak-ng).
"""
from __future__ import annotations

import numpy as np

from .. import pronuncia
from .base import MODELOS, ModeloAusente, Provedor

LANGS = {"pt": "pt-br", "en": "en-us", "es": "es", "fr": "fr-fr", "it": "it"}


def _lang() -> str:
    return LANGS.get(pronuncia.IDIOMA, pronuncia.IDIOMA)


class Kokoro(Provedor):
    nome = "kokoro"

    def __init__(self, voz=None, velocidade=1.0, **kw):
        super().__init__(voz=voz or "pm_alex", velocidade=velocidade, **kw)
        self._k = None

    def _motor(self):
        if self._k is None:
            try:
                from kokoro_onnx import Kokoro as K
            except ImportError as e:
                raise ModeloAusente("pip install kokoro-onnx") from e
            pasta = MODELOS / "kokoro"
            onnx, voices = pasta / "kokoro-v1.0.onnx", pasta / "voices-v1.0.bin"
            if not (onnx.exists() and voices.exists()):
                raise ModeloAusente(f"Pesos não encontrados em {pasta}. Rode: python scripts/baixar_modelos.py kokoro")
            self._k = K(str(onnx), str(voices))
        return self._k

    def _sintetizar_texto(self, texto, tentativa):
        k = self._motor()
        LANG = _lang()
        partes = pronuncia.dividir_por_fonemas(texto, self.nome)
        if len(partes) == 1 and not partes[0][1]:
            audio, sr = k.create(texto, voice=self.voz, speed=self.velocidade, lang=LANG)
            return audio, sr
        # monta a sequência inteira em fonemas para manter a prosódia contínua
        fon = []
        for trecho, e_fonema in partes:
            fon.append(trecho if e_fonema else k.tokenizer.phonemize(trecho, LANG))
        audio, sr = k.create(" ".join(f.strip() for f in fon if f.strip()), voice=self.voz,
                             speed=self.velocidade, lang=LANG, is_phonemes=True)
        return np.asarray(audio), sr
