"""Provedor Fish Audio (S2.1 Pro), voz em nuvem.

Dois modos, mesmo modelo:
  free -> s2.1-pro-free   US$ 0, uso justo, sem SLA de latência   [padrão]
  pro  -> s2.1-pro        US$ 15 por milhão de bytes UTF-8 do texto

Diferenciais em relação a um cliente "cru":
  1. Cache por conteúdo: a mesma frase, com a mesma voz, modelo e ajustes, nunca é
     gerada duas vezes. Re-renderizar um episódio não chama a API de novo (nem gasta).
  2. Livro-caixa + teto de gasto: toda chamada vai para out/fish_gastos.jsonl; no modo
     pro, a chamada é recusada se estourar FISH_ORCAMENTO_USD (padrão US$ 1,00).
  3. A/B: a mesma frase nos dois modos, com uma página HTML para ouvir lado a lado.
  4. Sem fallback automático free -> pro: pagar é sempre decisão explícita.
  5. O nome do modelo nunca vem de string livre: se o header "model" chegar errado,
     a API cai no s2.1-pro (pago). Aqui só existem as duas chaves de MODELOS.

Uso:
  FISH_API_KEY=... no .env da raiz (fora do git; ver .env.exemplo) ou no ambiente
  python -m tts.provedores.fish falar "Olá, eu sou o narrador." --voz <apelido-ou-reference_id>
  python -m tts.provedores.fish falar "Mesma frase, agora paga." --voz narrador --modo pro
  python -m tts.provedores.fish ab "Frase difícil um." "Frase difícil dois." --voz narrador
  python -m tts.provedores.fish ab --frases scripts/frases-ab.txt --voz narrador
  python -m tts.provedores.fish gastos

No código do pipeline:
  from tts.provedores.fish import Fish
  fish = Fish(modo="free", voz="narrador")
  info = fish.sintetizar("Olá, eu sou o narrador.", "audio/b1_s01.wav")

Dependências (PyPI): httpx
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

try:  # opcional (requirements-tts.txt): sem ele, o bake-off pula o Fish em vez de quebrar
    import httpx
except ImportError:
    httpx = None

API = "https://api.fish.audio"
MODELOS = {"free": "s2.1-pro-free", "pro": "s2.1-pro"}
USD_POR_MILHAO_DE_BYTES = {"free": 0.0, "pro": 15.0}
REPETIVEIS = {429, 500, 502, 503, 504}

RAIZ = Path(__file__).resolve().parents[2]
CACHE = RAIZ / "out" / "cache" / "fish"
LIVRO = RAIZ / "out" / "fish_gastos.jsonl"
VOZES = Path(__file__).with_name("fish_vozes.json")


class ErroFish(RuntimeError):
    pass


class OrcamentoExcedido(ErroFish):
    pass


def _ler_env(nome: str) -> str:
    """Variável de ambiente ou, na falta dela, linha NOME=valor do .env na raiz (fora do git)."""
    valor = os.environ.get(nome, "").strip()
    env = RAIZ / ".env"
    if valor or not env.exists():
        return valor
    for linha in env.read_text("utf-8").splitlines():
        chave, _, resto = linha.partition("=")
        if chave.strip() == nome:
            return resto.strip().strip("'\"")
    return ""


def chave_api() -> str:
    chave = _ler_env("FISH_API_KEY")
    if not chave:
        raise ErroFish("Defina FISH_API_KEY no .env da raiz ou no ambiente (fish.audio/app/api-keys).")
    return chave


def resolver_voz(voz: str | None) -> str | None:
    """Aceita um apelido de fish_vozes.json (ex.: 'narrador') ou um reference_id direto."""
    if not voz:
        return None
    if VOZES.exists():
        apelidos = json.loads(VOZES.read_text("utf-8"))
        if voz in apelidos:
            return apelidos[voz]["id"]
    return voz


def custo_estimado(texto: str, modo: str) -> float:
    return len(texto.encode("utf-8")) / 1_000_000 * USD_POR_MILHAO_DE_BYTES[modo]


def ler_livro() -> list[dict]:
    if not LIVRO.exists():
        return []
    return [json.loads(l) for l in LIVRO.read_text("utf-8").splitlines() if l.strip()]


def gasto_acumulado() -> float:
    return sum(r.get("usd", 0.0) for r in ler_livro())


@dataclass
class Fish:
    modo: str = "free"
    voz: str | None = None              # apelido ou reference_id; None = voz padrão da API
    formato: str = "wav"
    sample_rate: int = 44100
    temperatura: float = 0.7            # menor = mais estável entre gerações
    top_p: float = 0.7
    velocidade: float = 1.0             # 0,5 a 2,0
    normalizar: bool = False            # a do Fish estraga números em pt-BR; usamos pronuncia.py
    latencia: str = "normal"            # "normal" = mais estável; tempo real não importa aqui
    orcamento_usd: float = field(
        default_factory=lambda: float(_ler_env("FISH_ORCAMENTO_USD") or "1.00")
    )
    tentativas: int = 4
    timeout: float = 120.0

    def __post_init__(self) -> None:
        if self.modo not in MODELOS:
            raise ValueError(f"modo deve ser um de {sorted(MODELOS)}, veio {self.modo!r}")
        self.reference_id = resolver_voz(self.voz)

    @property
    def modelo(self) -> str:
        return MODELOS[self.modo]

    # ---------- montagem ----------
    def _payload(self, texto: str) -> dict:
        p = {
            "text": texto,
            "format": self.formato,
            "latency": self.latencia,
            "normalize": self.normalizar,
            "temperature": self.temperatura,
            "top_p": self.top_p,
            "prosody": {"speed": self.velocidade, "volume": 0},
        }
        if self.formato == "wav":
            p["sample_rate"] = self.sample_rate
        if self.reference_id:
            p["reference_id"] = self.reference_id
        return p

    def _chave_cache(self, payload: dict, variante: int) -> str:
        base = {"modelo": self.modelo, **payload}
        if variante:  # variante 0 mantém as chaves de cache já existentes
            base["variante"] = variante
        bruto = json.dumps(base, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(bruto.encode("utf-8")).hexdigest()[:24]

    # ---------- API pública ----------
    def sintetizar(self, texto: str, saida: str | Path, variante: int = 0) -> dict:
        """`variante` > 0 pede uma nova geração da mesma frase (repetição do narrar após
        reprovação do Whisper); cada variante tem o seu próprio cache."""
        texto = " ".join(texto.split())
        saida = Path(saida)
        payload = self._payload(texto)
        em_cache = CACHE / f"{self._chave_cache(payload, variante)}.{self.formato}"
        info = {
            "modo": self.modo,
            "modelo": self.modelo,
            "bytes": len(texto.encode("utf-8")),
            "cache": False,
            "usd": 0.0,
            "segundos": 0.0,
            "arquivo": str(saida),
        }

        if em_cache.exists():
            saida.parent.mkdir(parents=True, exist_ok=True)
            saida.write_bytes(em_cache.read_bytes())
            info["cache"] = True
            return info

        usd = custo_estimado(texto, self.modo)
        if usd:
            ja_gasto = gasto_acumulado()
            if ja_gasto + usd > self.orcamento_usd:
                raise OrcamentoExcedido(
                    f"Modo pro: esta frase custaria US$ {usd:.5f}; já gasto US$ {ja_gasto:.4f} "
                    f"de um teto de US$ {self.orcamento_usd:.2f}. Aumente FISH_ORCAMENTO_USD "
                    f"se for intencional."
                )

        t0 = time.monotonic()
        audio = self._chamar(payload)
        info["segundos"] = round(time.monotonic() - t0, 2)
        info["usd"] = round(usd, 6)

        CACHE.mkdir(parents=True, exist_ok=True)
        em_cache.write_bytes(audio)
        saida.parent.mkdir(parents=True, exist_ok=True)
        saida.write_bytes(audio)
        self._registrar(texto, info)
        return info

    # ---------- internos ----------
    def _chamar(self, payload: dict) -> bytes:
        if httpx is None:
            raise ErroFish("pip install httpx (ver requirements-tts.txt)")
        headers = {
            "Authorization": f"Bearer {chave_api()}",
            "Content-Type": "application/json",
            "model": self.modelo,
        }
        espera, erro = 2.0, ""
        for n in range(1, self.tentativas + 1):
            try:
                r = httpx.post(f"{API}/v1/tts", json=payload, headers=headers, timeout=self.timeout)
            except httpx.TransportError as e:
                erro = f"falha de rede ({type(e).__name__}): a API pode estar bloqueada nesta rede"
            else:
                if r.status_code == 200 and r.content:
                    return r.content
                erro = f"HTTP {r.status_code}: {r.text[:300]}"
                if r.status_code not in REPETIVEIS:
                    raise ErroFish(erro)
            if n < self.tentativas:
                time.sleep(espera)
                espera *= 2
        dica = " O modo free não tem SLA; tente mais tarde." if self.modo == "free" else ""
        raise ErroFish(f"Falhou após {self.tentativas} tentativas: {erro}.{dica}")

    def _registrar(self, texto: str, info: dict) -> None:
        LIVRO.parent.mkdir(parents=True, exist_ok=True)
        linha = {
            "quando": datetime.now().isoformat(timespec="seconds"),
            "modo": self.modo,
            "modelo": self.modelo,
            "voz": self.voz,
            "bytes": info["bytes"],
            "usd": info["usd"],
            "segundos": info["segundos"],
            "trecho": texto[:60],
        }
        with LIVRO.open("a", encoding="utf-8") as f:
            f.write(json.dumps(linha, ensure_ascii=False) + "\n")


# ---------- adaptador para o pipeline (narrar, bake-off) ----------
from .base import ModeloAusente, Provedor  # noqa: E402


class FishAudio(Provedor):
    """Fish como Provedor: `obter("fish", voz="narrador", modo="free")`.

    Falha de chave, rede, cota ou orçamento vira ModeloAusente: o bake-off pula a voz com o
    motivo em vez de interromper os outros candidatos."""

    nome = "fish"

    def __init__(self, voz=None, velocidade=1.0, modo="free", normalizar=False, temperatura=0.7, **kw):
        super().__init__(voz=voz, velocidade=velocidade, **kw)
        self._fish = Fish(modo=modo, voz=voz, velocidade=velocidade,
                          normalizar=normalizar, temperatura=temperatura)

    def descricao(self) -> str:
        return f"fish:{self._fish.modo}:{self.voz or 'padrão'} v={self.velocidade}"

    def _sintetizar_texto(self, texto, tentativa):
        import tempfile

        import soundfile as sf

        with tempfile.TemporaryDirectory() as tmp:
            arq = Path(tmp) / f"fala.{self._fish.formato}"
            try:
                self._fish.sintetizar(texto, arq, variante=tentativa)
            except ErroFish as e:
                raise ModeloAusente(f"Fish: {e}") from e
            audio, sr = sf.read(arq, dtype="float32", always_2d=True)
        return audio.mean(axis=1), sr


# ---------- A/B ----------
def ab(frases: list[str], voz: str | None, pasta: Path | None = None) -> Path:
    """Gera cada frase nos dois modos e monta index.html para ouvir lado a lado."""
    pasta = pasta or RAIZ / "out" / "fish_ab" / datetime.now().strftime("%Y-%m-%d_%H%M%S")
    pasta.mkdir(parents=True, exist_ok=True)
    total_pro = sum(custo_estimado(f, "pro") for f in frases)
    print(f"A/B de {len(frases)} frase(s); custo estimado do lado pro: US$ {total_pro:.5f}")

    motores = {m: Fish(modo=m, voz=voz) for m in MODELOS}
    linhas = []
    for i, frase in enumerate(frases, 1):
        celulas = []
        for modo, motor in motores.items():
            nome = f"{i:02d}_{modo}.{motor.formato}"
            try:
                info = motor.sintetizar(frase, pasta / nome)
                rotulo = "cache" if info["cache"] else f"{info['segundos']} s · US$ {info['usd']:.5f}"
                celulas.append(f'<td><audio controls src="{nome}"></audio><small>{rotulo}</small></td>')
            except ErroFish as e:
                celulas.append(f"<td class=erro>{html.escape(str(e))}</td>")
        linhas.append(f"<tr><th>{i}</th><td>{html.escape(frase)}</td>{''.join(celulas)}</tr>")

    (pasta / "index.html").write_text(
        "<!doctype html><meta charset=utf-8><title>Fish A/B</title>"
        "<style>body{font:14px system-ui;margin:24px}table{border-collapse:collapse;width:100%}"
        "td,th{border:1px solid #ccc;padding:8px;vertical-align:top}audio{width:100%}"
        "small{color:#666}.erro{color:#b00}</style>"
        f"<h1>Fish Audio · free × pro</h1><p>Voz: {html.escape(str(voz))}. "
        "Mesmo modelo nos dois lados: diferenças tendem a vir da amostragem, não da qualidade. "
        "Ouça sem olhar os rótulos.</p>"
        "<table><tr><th>#</th><th>Frase</th><th>free</th><th>pro</th></tr>"
        + "".join(linhas) + "</table>",
        encoding="utf-8",
    )
    return pasta / "index.html"


# ---------- CLI ----------
def _cli() -> None:
    ap = argparse.ArgumentParser(prog="fish", description="Narração via Fish Audio S2.1 Pro")
    sub = ap.add_subparsers(dest="cmd", required=True)

    f = sub.add_parser("falar", help="gera uma frase")
    f.add_argument("texto")
    f.add_argument("--voz")
    f.add_argument("--modo", choices=sorted(MODELOS), default="free")
    f.add_argument("--saida", default="out/fish_teste.wav")
    f.add_argument("--velocidade", type=float, default=1.0)

    a = sub.add_parser("ab", help="mesmas frases em free e pro, com página para ouvir")
    a.add_argument("textos", nargs="*")
    a.add_argument("--frases", help="arquivo .txt, uma frase por linha")
    a.add_argument("--voz")

    sub.add_parser("gastos", help="resumo do livro-caixa")

    args = ap.parse_args()
    try:
        if args.cmd == "falar":
            motor = Fish(modo=args.modo, voz=args.voz, velocidade=args.velocidade)
            print(json.dumps(motor.sintetizar(args.texto, args.saida), ensure_ascii=False, indent=2))
        elif args.cmd == "ab":
            frases = list(args.textos)
            if args.frases:
                frases += [l.strip() for l in Path(args.frases).read_text("utf-8").splitlines() if l.strip()]
            if not frases:
                ap.error("informe frases ou --frases")
            print(f"Abra: {ab(frases, args.voz)}")
        elif args.cmd == "gastos":
            registros = ler_livro()
            teto = float(_ler_env("FISH_ORCAMENTO_USD") or "1.00")
            for modo in MODELOS:
                rs = [r for r in registros if r["modo"] == modo]
                print(f"{modo:4}  {len(rs):4} chamadas  {sum(r['bytes'] for r in rs):8} bytes  "
                      f"US$ {sum(r['usd'] for r in rs):.4f}")
            print(f"teto (pro): US$ {teto:.2f} · restante: US$ {teto - gasto_acumulado():.4f}")
    except ErroFish as e:
        sys.exit(f"erro: {e}")


if __name__ == "__main__":
    _cli()
