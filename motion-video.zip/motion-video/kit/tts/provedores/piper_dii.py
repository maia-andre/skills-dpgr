"""Piper pt_BR-dii-high (voz feminina) via sherpa-onnx, CPU.

Pesos: python scripts/baixar_modelos.py piper-dii
       (GitHub releases k2-fsa/sherpa-onnx, tag tts-models → modelos/vits-piper-pt_BR-dii-high/)

Repetições (tentativa > 0) reduzem o ruído de amostragem, que costuma estabilizar palavras
que a voz "embola" (até 12 tentativas costuma resolver). Limite conhecido: "língua presa" no R
depois de consoante (padronizar, contratação), que dicionário não corrige.
"""
from __future__ import annotations

import numpy as np

from .base import MODELOS, ModeloAusente, Provedor

PASTA = "vits-piper-pt_BR-dii-high"


class PiperDii(Provedor):
    nome = "piper-dii"

    def __init__(self, voz=None, velocidade=0.97, **kw):
        super().__init__(voz=voz or "dii", velocidade=velocidade, **kw)
        self._motores = {}

    def _motor(self, ruido: float):
        if ruido in self._motores:
            return self._motores[ruido]
        try:
            import sherpa_onnx
        except ImportError as e:
            raise ModeloAusente("pip install sherpa-onnx") from e
        pasta = MODELOS / PASTA
        onnx = next(pasta.glob("*.onnx"), None) if pasta.exists() else None
        if onnx is None:
            raise ModeloAusente(f"Pesos não encontrados em {pasta}. Rode: python scripts/baixar_modelos.py piper-dii")
        cfg = sherpa_onnx.OfflineTtsConfig(
            model=sherpa_onnx.OfflineTtsModelConfig(
                vits=sherpa_onnx.OfflineTtsVitsModelConfig(
                    model=str(onnx),
                    tokens=str(pasta / "tokens.txt"),
                    data_dir=str(pasta / "espeak-ng-data"),
                    noise_scale=ruido,
                    noise_scale_w=0.8 * ruido / 0.667,
                ),
                num_threads=4,
            ),
        )
        self._motores[ruido] = sherpa_onnx.OfflineTts(cfg)
        return self._motores[ruido]

    def _sintetizar_texto(self, texto, tentativa):
        # tentativas 0-5: ruído padrão (variação natural); depois, ruído cada vez menor
        ruido = 0.667 if tentativa < 6 else max(0.2, 0.667 - 0.08 * (tentativa - 5))
        audio = self._motor(round(ruido, 3)).generate(texto, sid=0, speed=self.velocidade)
        return np.array(audio.samples, dtype=np.float32), audio.sample_rate
