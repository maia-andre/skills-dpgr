"""Interface comum dos provedores de TTS.

Um provedor novo = um arquivo neste diretório com uma classe que herda de Provedor e
implementa `_sintetizar_texto`. Registre o nome em REGISTRO (tts/provedores/__init__.py).
"""
from __future__ import annotations

import os
from pathlib import Path

import numpy as np

from .. import pronuncia

RAIZ = Path(__file__).resolve().parents[2]
MODELOS = Path(os.environ.get("TTS_MODELOS", RAIZ / "modelos"))


class ModeloAusente(RuntimeError):
    """Pesos ou pacote do provedor não encontrados. A mensagem diz como obter."""


class Provedor:
    nome = "base"
    #: provedores com conferência por Whisper desligada (ex.: silencio)
    conferivel = True

    def __init__(self, voz: str | None = None, velocidade: float = 1.0, extenso: bool = False, **opcoes):
        self.voz = voz
        self.velocidade = velocidade
        self.extenso = extenso  # expandir números por extenso antes de sintetizar
        self.opcoes = opcoes

    # --- API pública -------------------------------------------------------
    def preparar(self, texto: str) -> str:
        """Texto que efetivamente vai para a voz (dicionário + números)."""
        return pronuncia.aplicar(texto, self.nome, extenso=self.extenso)

    def sintetizar(self, texto: str, tentativa: int = 0) -> tuple[np.ndarray, int]:
        """Devolve (amostras float32 mono em [-1, 1], taxa de amostragem).
        `tentativa` > 0 permite ao provedor variar semente/ruído na repetição."""
        audio, sr = self._sintetizar_texto(self.preparar(texto), tentativa)
        audio = np.asarray(audio, dtype=np.float32).reshape(-1)
        return audio, int(sr)

    def descricao(self) -> str:
        return f"{self.nome}:{self.voz or 'padrão'} v={self.velocidade}"

    # --- implementar -------------------------------------------------------
    def _sintetizar_texto(self, texto: str, tentativa: int) -> tuple[np.ndarray, int]:
        raise NotImplementedError
