"""Registro de provedores. Importação preguiçosa: só carrega o pacote pesado do provedor usado."""
from __future__ import annotations

from importlib import import_module

from .base import ModeloAusente, Provedor  # noqa: F401

REGISTRO = {
    "silencio": "tts.provedores.silencio:Silencio",
    "piper-dii": "tts.provedores.piper_dii:PiperDii",
    "kokoro": "tts.provedores.kokoro:Kokoro",
    "gravacao": "tts.provedores.gravacao:Gravacao",
    "fish": "tts.provedores.fish:FishAudio",
}


def obter(nome: str, **opcoes) -> Provedor:
    if nome not in REGISTRO:
        raise SystemExit(f"Provedor desconhecido: {nome}. Opções: {', '.join(REGISTRO)}")
    modulo, classe = REGISTRO[nome].split(":")
    return getattr(import_module(modulo), classe)(**opcoes)
