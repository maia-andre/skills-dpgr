"""Provedor de teste: silêncio com a duração estimada da fala (~145 palavras/min).
Serve para montar e renderizar cenas antes de escolher a voz."""
import numpy as np

from .base import Provedor

PPM = 145


class Silencio(Provedor):
    nome = "silencio"
    conferivel = False

    def _sintetizar_texto(self, texto, tentativa):
        sr = 24000
        palavras = max(1, len(texto.split()))
        dur = palavras / (PPM / 60) / max(self.velocidade, 0.1)
        return np.zeros(int(dur * sr), dtype=np.float32), sr
