"""Voz humana gravada: cada frase vem de gravacao/<bloco>.<n>.wav na pasta do vídeo.

Gere o roteiro de gravação com `python scripts/fatiar_gravacao.py <video> --roteiro` (lista as frases
com os ids b1.1, b1.2…). Grave uma frase por arquivo, ou um arquivo por bloco (gravacao/b1.wav) e
fatie pelos silêncios com `python scripts/fatiar_gravacao.py <video>`.

A conferência por Whisper continua valendo (pega frase trocada ou lida pela metade), com uma única
tentativa: não há o que re-sortear numa gravação. Sem cache: regravou, o narrar pega o arquivo novo.
"""
from pathlib import Path

import soundfile as sf

from .base import ModeloAusente, Provedor


class Gravacao(Provedor):
    nome = "gravacao"
    usa_cache = False
    deterministico = True

    def __init__(self, pasta: str | None = None, **kw):
        super().__init__(**kw)
        self.pasta = Path(pasta) if pasta else None
        self.frase_id = None

    def descricao(self) -> str:
        return "gravacao"

    def preparar(self, texto: str) -> str:
        return texto  # dicionário de pronúncia não se aplica a voz humana

    def _sintetizar_texto(self, texto, tentativa):
        if self.pasta is None:
            raise ModeloAusente('defina "opcoes": {"pasta": "<video>/gravacao"} no narracao.json')
        arq = self.pasta / f"{self.frase_id}.wav"
        if not arq.exists():
            raise ModeloAusente(f"falta a gravação {arq} (frase: {texto[:60]})")
        audio, sr = sf.read(arq, dtype="float32", always_2d=True)
        return audio.mean(axis=1), sr
