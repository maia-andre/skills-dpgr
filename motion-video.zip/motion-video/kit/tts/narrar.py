"""Gera a narração de um episódio: narracao.json → audio/<bloco>.wav + audio/timing.json/.js

Uso:
  python -m tts.narrar videos/meu-video                      # todos os blocos, voz do narracao.json
  python -m tts.narrar videos/meu-video --blocos b2,b4       # só alguns blocos (vírgula, sem espaço)
  python -m tts.narrar videos/meu-video --provedor silencio  # sem voz, duração estimada
  python -m tts.narrar videos/meu-video --sem-conferencia    # pula o Whisper
  python -m tts.narrar videos/meu-video --idioma en          # narracao.en.json → audio/en/

Cada frase é sintetizada até `tentativas` vezes e conferida por Whisper; fica a melhor.
Frases sem mudança (mesmo texto preparado + mesma voz) vêm do cache em audio/cache/.
Sai com código 1 se alguma frase não passou na conferência (o áudio é gerado mesmo assim).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

from . import conferencia_whisper as cw
from . import pronuncia
from .provedores import ModeloAusente, obter

PAUSA_INICIAL = 0.15


def frases_do_bloco(bloco: dict) -> list[dict]:
    """Aceita "fala": "parágrafo" (dividido por . ? !) ou "falas": [{"texto", "expect"?, "pausa_depois"?, "velocidade"?}]."""
    if "falas" in bloco:
        return [f if isinstance(f, dict) else {"texto": f} for f in bloco["falas"]]
    partes = re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ\"“])", bloco.get("fala", "").strip())
    return [{"texto": p} for p in partes if p]


def aparar(audio: np.ndarray, sr: int, limiar: float = 0.01, margem: float = 0.03) -> np.ndarray:
    if not len(audio) or np.max(np.abs(audio)) < limiar:
        return audio
    idx = np.where(np.abs(audio) >= limiar)[0]
    m = int(margem * sr)
    return audio[max(0, idx[0] - m): idx[-1] + m]


def chave_cache(prov, texto: str) -> str:
    return hashlib.sha1(f"{prov.descricao()}|{prov.preparar(texto)}".encode()).hexdigest()[:16]


def sintetizar_frase(prov, frase: dict, cfg: dict, cache: Path, conferir: bool, forcar: bool) -> dict:
    texto = frase["texto"]
    ch = chave_cache(prov, texto)
    wav, meta = cache / f"{ch}.wav", cache / f"{ch}.json"
    if wav.exists() and meta.exists() and not forcar and getattr(prov, "usa_cache", True):
        audio, sr = sf.read(wav, dtype="float32")
        return {**json.loads(meta.read_text(encoding="utf-8")), "audio": audio, "sr": sr, "cache": True}

    esperado = [texto] + ([frase["expect"]] if frase.get("expect") else [])
    criticas = cfg["criticas"] + frase.get("checar", [])
    melhor = None
    unica = not conferir or getattr(prov, "deterministico", False)  # gravação humana: uma tentativa só
    for tent in range(1 if unica else cfg["tentativas"]):
        audio, sr = prov.sintetizar(texto, tentativa=tent)
        audio = aparar(audio, sr)
        if conferir:
            av = cw.avaliar(esperado, cw.transcrever(audio, sr), criticas, cfg["limiar"])
        else:
            av = {"ok": None, "nota": None, "faltando": [], "transcricao": None}
        cand = {**av, "tentativa": tent + 1, "audio": audio, "sr": sr}
        if melhor is None or (av["nota"] or 0) > (melhor["nota"] or 0):
            melhor = cand
        if not conferir or av["ok"]:
            break
    sf.write(wav, melhor["audio"], melhor["sr"])
    meta.write_text(json.dumps({k: v for k, v in melhor.items() if k not in ("audio", "sr")},
                               ensure_ascii=False), encoding="utf-8")
    return {**melhor, "cache": False}


def narrar(ep: Path, provedor: str | None, voz: str | None, blocos_sel: set[str] | None,
           conferir: bool, forcar: bool, tentativas: int | None, idioma: str | None = None) -> int:
    nome_roteiro = f"narracao.{idioma}.json" if idioma and idioma != "pt" else "narracao.json"
    roteiro = json.loads((ep / nome_roteiro).read_text(encoding="utf-8"))
    idioma = roteiro.get("idioma", idioma or "pt")
    pronuncia.definir_idioma(idioma)
    cfg_voz = dict(roteiro.get("voz", {}))
    if provedor:
        cfg_voz = {"provedor": provedor}
    if voz:
        cfg_voz["voz"] = voz
    nome = cfg_voz.pop("provedor", "silencio")
    opcoes = cfg_voz.pop("opcoes", {})
    if nome == "gravacao":
        opcoes.setdefault("pasta", str(ep / "gravacao"))
    prov = obter(nome, **cfg_voz, **opcoes)
    provs = {cfg_voz.get("velocidade", 1.0): prov}

    def prov_da_frase(fr: dict):
        """Frase com "velocidade" própria (ex.: palavra que embola) usa outra instância da mesma voz."""
        v = fr.get("velocidade")
        if v is None:
            return prov
        if v not in provs:
            provs[v] = obter(nome, **{**cfg_voz, "velocidade": v}, **opcoes)
        return provs[v]

    if conferir and prov.conferivel and not cw.disponivel():
        print("! Whisper não instalado — seguindo sem conferência (python scripts/baixar_modelos.py whisper)")
    conferir = conferir and prov.conferivel and cw.disponivel()

    cfg = {
        "tentativas": tentativas or roteiro.get("tentativas", 12),
        "limiar": roteiro.get("limiar", cw.LIMIAR_PADRAO),
        "criticas": pronuncia.carregar().get("palavras_criticas", []) + roteiro.get("checar", []),
    }
    pausa = roteiro.get("pausa_frase", 0.55)

    pasta = ep / "audio" if idioma == "pt" else ep / "audio" / idioma  # outro idioma: audio/<idioma>/
    cache = pasta / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    tj = pasta / "timing.json"
    timing = json.loads(tj.read_text(encoding="utf-8")) if tj.exists() and blocos_sel else {}
    relatorio, falhas = [], 0

    print(f"Roteiro: {nome_roteiro} · idioma {idioma}")
    print(f"Voz: {prov.descricao()} · conferência: {'sim' if conferir else 'não'}")
    for bloco in roteiro["blocos"]:
        bid = bloco["id"]
        if blocos_sel and bid not in blocos_sel:
            continue
        partes, frases, t, sr_bloco = [], [], PAUSA_INICIAL, None
        for i, fr in enumerate(frases_do_bloco(bloco)):
            prov_da_frase(fr).frase_id = f"{bid}.{i + 1}"  # usado pelo provedor 'gravacao'
            try:
                r = sintetizar_frase(prov_da_frase(fr), fr, cfg, cache, conferir, forcar)
            except ModeloAusente as e:
                print(f"\n✗ {prov.nome}: {e}")
                return 2
            if sr_bloco is None:
                sr_bloco = r["sr"]
                partes.append(np.zeros(int(PAUSA_INICIAL * sr_bloco), np.float32))
            dur = len(r["audio"]) / r["sr"]
            frases.append({"t": round(t, 3), "dur": round(dur, 3), "texto": fr["texto"]})
            depois = fr.get("pausa_depois", pausa)  # silêncio extra para segurar a tela (ex.: "para guardar")
            partes += [r["audio"], np.zeros(int(depois * sr_bloco), np.float32)]
            t += dur + depois
            marca = "·" if r["ok"] is None else ("✓" if r["ok"] else "✗")
            falhas += r["ok"] is False
            extra = "" if r["ok"] is None else f" nota {r['nota']} (tent. {r['tentativa']}{', cache' if r['cache'] else ''})"
            print(f"  {marca} {bid}.{i + 1}{extra}  {fr['texto'][:70]}")
            if r["ok"] is False:
                print(f"      ouviu: {r['transcricao']}" + (f"  | faltou: {r['faltando']}" if r["faltando"] else ""))
            relatorio.append({"bloco": bid, "frase": i + 1, "texto": fr["texto"],
                              **{k: r[k] for k in ("ok", "nota", "faltando", "transcricao", "tentativa")}})
        audio = np.concatenate(partes) if partes else np.zeros(1, np.float32)
        sf.write(pasta / f"{bid}.wav", audio, sr_bloco or 24000)
        timing[bid] = {"dur": round(len(audio) / (sr_bloco or 24000), 3), "frases": frases,
                       "voz": prov.descricao()}

    tj.write_text(json.dumps(timing, ensure_ascii=False, indent=1), encoding="utf-8")
    (pasta / "timing.js").write_text("window.TIMING = " + json.dumps(timing, ensure_ascii=False) + ";\n",
                                     encoding="utf-8")
    rel = pasta / "relatorio.json"
    if blocos_sel and rel.exists():  # só alguns blocos: preserva o relatório dos outros
        antigos = [r for r in json.loads(rel.read_text(encoding="utf-8")) if r["bloco"] not in blocos_sel]
        ordem = [b["id"] for b in roteiro["blocos"]]
        relatorio = sorted(antigos + relatorio, key=lambda r: (ordem.index(r["bloco"]) if r["bloco"] in ordem else 99, r["frase"]))
    rel.write_text(json.dumps(relatorio, ensure_ascii=False, indent=1), encoding="utf-8")
    total = sum(b["dur"] for b in timing.values())
    print(f"\nNarração: {len(timing)} blocos, {total:.1f} s de fala. Falhas de conferência: {falhas}")
    return 1 if falhas else 0


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("episodio", type=Path)
    p.add_argument("--provedor")
    p.add_argument("--voz")
    p.add_argument("--blocos", help="ex.: b2,b4")
    p.add_argument("--tentativas", type=int)
    p.add_argument("--sem-conferencia", action="store_true")
    p.add_argument("--forcar", action="store_true", help="ignora o cache")
    p.add_argument("--idioma", help="en, es…: lê narracao.<idioma>.json e grava em audio/<idioma>/")
    a = p.parse_args(argv)
    sel = set(a.blocos.split(",")) if a.blocos else None
    sys.exit(narrar(a.episodio, a.provedor, a.voz, sel, not a.sem_conferencia, a.forcar, a.tentativas, a.idioma))


if __name__ == "__main__":
    main()
