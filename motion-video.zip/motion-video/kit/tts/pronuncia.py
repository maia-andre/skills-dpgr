"""Dicionário de pronúncia, normalização de números e normalização para comparação.

- aplicar(texto, provedor): troca palavras pelo que a voz deve LER (não muda o roteiro).
- dividir_por_fonemas(texto, provedor): separa trechos que vão como fonemas (kokoro).
- numeros_por_extenso(texto): R$ 18.315,00 → "dezoito mil trezentos e quinze reais" (opcional; usa num2words).
  Código de 6+ dígitos sem ponto (147288) é lido em grupos: "cento e quarenta e sete, duzentos e oitenta e oito".
- para_comparar(texto): forma canônica para comparar roteiro × transcrição do Whisper.

Idioma: pt por padrão. definir_idioma("en") (o narrar faz isso a partir do "idioma" do narracao.json)
troca o dicionário para pronuncia.<idioma>.json, os números para num2words(<idioma>) e o Whisper.
"""
from __future__ import annotations

import json
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

ARQUIVO = Path(__file__).with_name("pronuncia.json")
IDIOMA = "pt"
_N2W = {"pt": "pt_BR", "en": "en", "es": "es"}


def definir_idioma(idioma: str | None) -> None:
    global IDIOMA
    IDIOMA = idioma or "pt"


def arquivo(idioma: str | None = None) -> Path:
    i = idioma or IDIOMA
    return ARQUIVO if i == "pt" else ARQUIVO.with_name(f"pronuncia.{i}.json")


@lru_cache(maxsize=None)
def _ler(caminho: Path) -> dict:
    return json.loads(caminho.read_text(encoding="utf-8")) if caminho.exists() else {}


def carregar() -> dict:
    return _ler(arquivo())


def _mapa(provedor: str | None) -> dict[str, str]:
    d = carregar()
    m = dict(d.get("texto", {}))
    if provedor:
        m.update(d.get("por_provedor", {}).get(provedor, {}))
    return m


def _trocar(texto: str, mapa: dict[str, str]) -> str:
    # chaves mais longas primeiro, palavra inteira (permite hífen/dígito dentro da chave, ex.: NR-17)
    for chave in sorted(mapa, key=len, reverse=True):
        padrao = r"(?<![\w-])" + re.escape(chave) + r"(?![\w-])"
        texto = re.sub(padrao, mapa[chave], texto)
    return texto


def aplicar(texto: str, provedor: str | None = None, extenso: bool = False) -> str:
    """Texto que será enviado à voz."""
    texto = _trocar(texto, _mapa(provedor))  # dicionário antes: chaves podem conter dígitos (NR-17)
    return numeros_por_extenso(texto) if extenso else texto


def dividir_por_fonemas(texto: str, provedor: str) -> list[tuple[str, bool]]:
    """Divide o texto em [(trecho, é_fonema)]. Trechos com fonema já vêm convertidos."""
    fon = carregar().get("fonemas", {}).get(provedor, {})
    if not fon:
        return [(texto, False)]
    padrao = "|".join(r"(?<![\w-])" + re.escape(k) + r"(?![\w-])" for k in sorted(fon, key=len, reverse=True))
    partes, pos = [], 0
    for m in re.finditer(padrao, texto):
        if m.start() > pos:
            partes.append((texto[pos:m.start()], False))
        partes.append((fon[m.group(0)], True))
        pos = m.end()
    if pos < len(texto):
        partes.append((texto[pos:], False))
    return partes


# ---------------------------------------------------------------- números

def _n2w(n: int | float) -> str:
    try:
        from num2words import num2words
    except ImportError:  # sem num2words, devolve os dígitos (a voz lê do jeito dela)
        return str(n)
    return num2words(n, lang=_N2W.get(IDIOMA, IDIOMA)).replace(",", "")


def _inteiro(s: str) -> int:
    return int(s.replace(".", ""))


def numeros_por_extenso(texto: str) -> str:
    if IDIOMA != "pt":  # fora do pt: só inteiros (roteiro em outro idioma já escreve valores por extenso)
        return re.sub(r"\b\d+\b", lambda m: _n2w(int(m.group(0))), texto)
    return _numeros_pt(texto)


def _numeros_pt(texto: str) -> str:
    """Expande valores em reais, porcentagens, m² e números com separador de milhar.
    Atenção: num2words usa o masculino ("trezentos e vinte cadeiras"). Para concordância no feminino,
    escreva por extenso no roteiro."""
    def reais(m):
        inteiro, cent = _inteiro(m.group(1)), int(m.group(2) or 0)
        s = f"{_n2w(inteiro)} {'real' if inteiro == 1 else 'reais'}"
        if cent:
            s += f" e {_n2w(cent)} {'centavo' if cent == 1 else 'centavos'}"
        return s

    texto = re.sub(r"R\$\s?(\d{1,3}(?:\.\d{3})*|\d+)(?:,(\d{2}))?", reais, texto)
    texto = re.sub(r"(\d+(?:,\d+)?)\s?%", lambda m: f"{_dec(m.group(1))} por cento", texto)
    texto = re.sub(r"(\d{1,3}(?:\.\d{3})+|\d+)\s?m²", lambda m: f"{_n2w(_inteiro(m.group(1)))} metros quadrados", texto)
    texto = re.sub(r"\b\d+,\d+\b", lambda m: _dec(m.group(0)), texto)
    texto = re.sub(r"\b\d{1,3}(?:\.\d{3})+\b", lambda m: _n2w(_inteiro(m.group(0))), texto)
    texto = re.sub(r"\b\d{6,}\b", lambda m: _codigo(m.group(0)), texto)
    texto = re.sub(r"\b\d+\b", lambda m: _n2w(int(m.group(0))), texto)
    return texto


def _codigo(s: str) -> str:
    """Código longo sem ponto de milhar (147288): lido em grupos de três, com pausa entre eles.
    Lido de uma vez, vira número enorme e a voz atropela o início ('come o 1')."""
    grupos = [s[max(0, i - 3):i] for i in range(len(s), 0, -3)][::-1]
    return ", ".join(" ".join(_n2w(int(d)) for d in g) if g.startswith("0") else _n2w(int(g))
                     for g in grupos)


def _dec(s: str) -> str:
    if "," not in s:
        return _n2w(int(s))
    a, b = s.split(",", 1)
    return f"{_n2w(int(a))} vírgula {_n2w(int(b))}"


# ---------------------------------------------------------------- comparação

_FEMININO = {
    "uma": "um", "duas": "dois", "duzentas": "duzentos", "trezentas": "trezentos",
    "quatrocentas": "quatrocentos", "quinhentas": "quinhentos", "seiscentas": "seiscentos",
    "setecentas": "setecentos", "oitocentas": "oitocentos", "novecentas": "novecentos",
}


def _sem_acento(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def para_comparar(texto: str) -> list[str]:
    """Lista de palavras canônicas: números por extenso, sem acento, sem pontuação, sem feminino numérico."""
    t = numeros_por_extenso(texto).lower()
    t = _sem_acento(t)
    t = re.sub(r"[^a-z0-9 ]+", " ", t)
    if IDIOMA != "pt":
        return t.split()
    # "por que", "porque" e "por quê" soam iguais; o Whisper escolhe a grafia ao acaso
    t = re.sub(r"\bpor que\b", "porque", t)
    # sem "mil": o Whisper escreve o código 147288 como "147.288", que por extenso ganha um "mil"
    return [_FEMININO.get(w, w) for w in t.split() if w != "mil"]
