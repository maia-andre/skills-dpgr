# <Título do vídeo>

Briefing completo em `briefing.md`. Roteiro em `roteiro.md` (fala × tela por bloco); a fala que vale é a do
`narracao.json`.

- `narracao.json` → `python -m tts.narrar <esta pasta>` → `audio/bN.wav` + `audio/timing.js`.
- `episodio.html` → uma `Motor.cena()` por bloco; texto-chave com `data-frase="bN.K"` (K começa em 1).
- `projeto.json` → fase, voz, música, pendências e histórico de decisões. Atualize a cada etapa.
- `referencias/` → material que o usuário mandou (fora do git se for pesado ou sensível).
- `audio/` e `out/` são gerados.

## Decisões
<!-- uma linha por decisão, com data: voz escolhida e por quê, cortes de roteiro, pedidos do revisor -->
