"""Trilha de fundo ORIGINAL, sintetizada e determinística, no tempo do vídeo (lê o Motor.plano()).

  python scripts/trilha.py videos/meu-video                       # clima "claro" (maior), 92 bpm
  python scripts/trilha.py videos/meu-video --clima noturno --bpm 76 --semente 7
  python scripts/trilha.py videos/meu-video --query "lang=en"     # variante (mesma --query do render)
  → videos/meu-video/audio/trilha.wav ; render com --fundo <video>/audio/trilha.wav --ducking 6

Por que sintetizar: música de terceiros quase sempre tem direitos (mesmo "só um trecho"). Isto gera
uma base discreta e livre. Estrutura: intro só com pad no 1º bloco, arpejo do 2º ao penúltimo,
o último bloco volta ao pad e fecha num acorde que soa até o fim. Para algo mais elaborado, edite
PROGRESSOES ou peça ao usuário um arquivo de música com licença clara.

Os tempos vêm do próprio episódio (render.ler_plano): mudou a narração, rode de novo. Nunca copie
PAD/extra para cá: a fonte única de tempo é o Motor.plano().
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

SR = 48000
# (baixo, [notas do acorde]) em MIDI
PROGRESSOES = {
    "claro": [(38, [50, 57, 62, 66]), (33, [49, 52, 57, 64]), (35, [50, 54, 59, 66]), (31, [50, 55, 59, 67])],  # D A Bm G
    "noturno": [(38, [50, 53, 57, 62]), (34, [50, 53, 58, 62]), (36, [48, 52, 55, 60]), (33, [49, 52, 57, 64])],  # Dm Bb C A
    "neutro": [(36, [48, 52, 55, 62]), (33, [48, 52, 57, 60]), (29, [48, 53, 57, 60]), (31, [50, 55, 59, 62])],  # C Am F G
}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("video", type=Path)
    p.add_argument("--clima", choices=PROGRESSOES, default="claro")
    p.add_argument("--bpm", type=float, default=92)
    p.add_argument("--semente", type=int, default=11)
    p.add_argument("--query", default="")
    p.add_argument("--saida", type=Path)
    a = p.parse_args()
    os.environ["RENDER_QUERY"] = a.query
    from render.render import ler_plano, pasta_audio

    ep = a.video.resolve()
    plano, _, _ = ler_plano(ep)
    TOT = plano[-1]["inicio"] + plano[-1]["dur"]
    N = int(TOT * SR) + 1
    x = np.zeros(N)
    rng = np.random.default_rng(a.semente)
    f = lambda m: 440 * 2 ** ((m - 69) / 12)  # noqa: E731

    def pad(ms, t0, t1, amp=0.2, atq=1.6, rel=2.2):
        i, j = int(max(t0, 0) * SR), min(int((t1 + rel) * SR), N)
        n = j - i
        if n <= 0:
            return
        tt = np.arange(n) / SR
        env = np.minimum(tt / atq, 1) * np.minimum((n - np.arange(n)) / (rel * SR), 1)
        env = env * env * (3 - 2 * env)
        s = np.zeros(n)
        for m in ms:
            for h, amp_h in ((1, 1), (2, 0.32), (3, 0.1), (4, 0.05)):
                for d in (-0.0016, 0.0016):  # leve desafinação = coro
                    s += amp_h * np.sin(2 * np.pi * f(m) * h * (1 + d) * tt + rng.uniform(0, 6.28))
        x[i:j] += amp / len(ms) * s * env

    def pluck(m, t0, amp=0.1, dec=2.6):
        i = int(t0 * SR)
        n = min(int(1.8 * SR), N - i)
        if n <= 0:
            return
        tt = np.arange(n) / SR
        x[i:i + n] += amp * (np.sin(2 * np.pi * f(m) * tt) + 0.28 * np.sin(4 * np.pi * f(m) * tt) * np.exp(-tt * 4)) \
            * np.exp(-tt * dec) * np.minimum(tt / 0.004, 1)

    CH = PROGRESSOES[a.clima]
    col = 60 / a.bpm / 2
    compasso = col * 16
    padrao = [0, 1, 2, 3, 4, 3, 5, 2, 0, 2, 1, 3, 6, 3, 2, 1]
    fim_intro = plano[1]["inicio"] if len(plano) > 2 else min(6, TOT / 4)
    ini_fecho = plano[-1]["inicio"] if len(plano) > 2 else TOT - min(6, TOT / 4)

    pad([CH[0][0]] + CH[0][1][:3], 0, fim_intro - 0.3, 0.24, atq=2.5)
    q, k = fim_intro, 0
    while q < ini_fecho - 0.5:
        b, ac = CH[k % len(CH)]
        u = min(q + compasso, ini_fecho)
        pad([b] + ac, q, u, 0.22, atq=1.1, rel=1.8)
        notas = ac + [ac[-1] + 12, ac[2] + 12, ac[1] + 12]
        for n_ in range(16):
            z = q + n_ * col
            if z >= ini_fecho:
                break
            pluck(notas[padrao[n_]] + 12, z, 0.11 if n_ % 4 == 0 else 0.08)
        q += compasso
        k += 1
    b, ac = CH[0]
    pad([b, b + 12] + ac, ini_fecho, TOT - 2.2, 0.3, atq=1.0, rel=2)
    for n_, z in zip([ac[-1] + 12, ac[1] + 24, ac[2] + 24], [0, 0.3, 0.6]):
        pluck(n_, ini_fecho + z, 0.14, dec=1.4)

    fade = int(2.0 * SR)
    x[-fade:] *= np.linspace(1, 0, fade)
    x = np.tanh(x * 1.2)
    x = x / (np.max(np.abs(x)) or 1) * 0.89
    saida = a.saida or pasta_audio(ep) / "trilha.wav"
    sf.write(saida, x.astype(np.float32), SR)
    print(f"Trilha: {saida} ({TOT:.1f} s, clima {a.clima}, {a.bpm:g} bpm, semente {a.semente})")


if __name__ == "__main__":
    main()
