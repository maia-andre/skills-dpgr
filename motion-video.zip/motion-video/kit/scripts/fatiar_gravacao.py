"""Voz gravada por uma pessoa → um wav por frase, no formato que o provedor 'gravacao' lê.

  python scripts/fatiar_gravacao.py videos/meu-video --roteiro   # gravacao/ROTEIRO.txt: o que ler, frase a frase
  python scripts/fatiar_gravacao.py videos/meu-video             # fatia gravacao/bN.wav em gravacao/bN.K.wav

Como gravar: um arquivo por bloco (gravacao/b1.wav, b2.wav…), lendo as frases na ordem, com uma pausa
clara (~1 s) entre elas. O script corta nos silêncios mais longos, tantos quantos o bloco tem frases.
Se o número de trechos não bater, ele avisa: regrave o bloco ou grave as frases soltas (bN.K.wav).
Depois: "voz": {"provedor": "gravacao"} no narracao.json e python -m tts.narrar <video>.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tts.narrar import frases_do_bloco  # noqa: E402

SR = 48000


def ler(arq: Path) -> np.ndarray:
    out = subprocess.run(["ffmpeg", "-v", "error", "-i", str(arq), "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                         check=True, capture_output=True).stdout
    return np.frombuffer(out, dtype=np.float32)


def cortes(audio: np.ndarray, n: int, janela: float = 0.02) -> list[tuple[int, int]] | None:
    """Divide em n trechos de fala usando os n-1 silêncios mais longos."""
    w = int(janela * SR)
    env = np.sqrt(np.convolve(audio ** 2, np.ones(w) / w, "same"))
    limiar = max(0.01, np.percentile(env, 30) * 3)
    voz = env > limiar
    # trechos de silêncio (início, fim) com pelo menos 0,35 s
    mud, i = [], 0
    while i < len(voz):
        if not voz[i]:
            j = i
            while j < len(voz) and not voz[j]:
                j += 1
            if j - i > 0.35 * SR and i > 0 and j < len(voz):
                mud.append((i, j))
            i = j
        else:
            i += 1
    if len(mud) < n - 1:
        return None
    escolhidos = sorted(sorted(mud, key=lambda m: m[1] - m[0], reverse=True)[: n - 1])
    fala = np.where(voz)[0]
    ini, fim = fala[0], fala[-1]
    pontos = [ini] + [x for m in escolhidos for x in m] + [fim]
    m = int(0.05 * SR)
    return [(max(0, pontos[k] - m), min(len(audio), pontos[k + 1] + m)) for k in range(0, len(pontos), 2)]


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    ep = Path(sys.argv[1])
    roteiro = json.loads((ep / "narracao.json").read_text(encoding="utf-8"))
    pasta = ep / "gravacao"
    pasta.mkdir(exist_ok=True)
    if "--roteiro" in sys.argv:
        linhas = []
        for b in roteiro["blocos"]:
            linhas.append(f"\n=== {b['id']} · {b.get('cena', '')}  →  grave em gravacao/{b['id']}.wav")
            linhas += [f"  {b['id']}.{i + 1}  {f['texto']}" for i, f in enumerate(frases_do_bloco(b))]
        (pasta / "ROTEIRO.txt").write_text("\n".join(linhas).strip() + "\n", encoding="utf-8")
        print(f"Roteiro de gravação: {pasta / 'ROTEIRO.txt'}")
        return
    erros = 0
    for b in roteiro["blocos"]:
        arq = pasta / f"{b['id']}.wav"
        n = len(frases_do_bloco(b))
        if not arq.exists():
            print(f"  · {b['id']}: sem {arq.name} (ok se gravou as frases soltas)")
            continue
        audio = ler(arq)
        cs = cortes(audio, n)
        if cs is None:
            print(f"  ✗ {b['id']}: esperava {n} frases e não achou pausas suficientes — regrave com pausas maiores")
            erros += 1
            continue
        for k, (i, j) in enumerate(cs, 1):
            sf.write(pasta / f"{b['id']}.{k}.wav", audio[i:j], SR)
        print(f"  ✓ {b['id']}: {n} frases")
    sys.exit(1 if erros else 0)


if __name__ == "__main__":
    main()
