"""Gera os efeitos sonoros da marca em marca/sons/ (sintetizados, determinísticos, sem download).

  python scripts/gerar_sons.py

- guardar.wav      sino suave (duas parciais, decaimento lento): frase do "Para guardar"
- acerto.wav       "ding" curto e brilhante: entrada do ✔ no erro comum
- encerramento.wav duas notas ascendentes com cauda: cartão final da série

Os episódios marcam os instantes com efeito('nome', t); o render/mix.py posiciona cada som na trilha.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import soundfile as sf

SR = 48000
PASTA = Path(__file__).resolve().parents[1] / "marca" / "sons"


def nota(freq: float, dur: float, decai: float, parciais=((1, 1.0), (2.01, 0.35), (3.02, 0.12)), ataque=0.006):
    t = np.arange(int(dur * SR)) / SR
    onda = sum(a * np.sin(2 * np.pi * freq * m * t) * np.exp(-t * decai * m ** 0.5) for m, a in parciais)
    env = np.minimum(1, t / ataque)
    return (onda * env).astype(np.float32)


def normalizar(x: np.ndarray, pico_db: float) -> np.ndarray:
    return (x / np.max(np.abs(x)) * 10 ** (pico_db / 20)).astype(np.float32)


def misturar(*partes: tuple[float, np.ndarray]) -> np.ndarray:
    fim = max(int(t0 * SR) + len(x) for t0, x in partes)
    out = np.zeros(fim, np.float32)
    for t0, x in partes:
        i = int(t0 * SR)
        out[i:i + len(x)] += x
    return out


def main():
    PASTA.mkdir(parents=True, exist_ok=True)
    sons = {
        "guardar": misturar((0, nota(784.0, 2.4, 2.2)), (0.0, 0.5 * nota(1175.0, 2.0, 3.0))),  # sol5 + ré6
        "acerto": misturar((0, nota(1318.5, 0.7, 7.0)), (0.07, 0.8 * nota(1760.0, 0.8, 6.0))),  # mi6 → lá6
        "encerramento": misturar((0, nota(523.3, 2.6, 1.8)), (0.22, nota(784.0, 3.0, 1.5)),     # dó5 → sol5 → dó6
                                 (0.44, 0.7 * nota(1046.5, 3.2, 1.4))),
    }
    for nome, x in sons.items():
        sf.write(PASTA / f"{nome}.wav", normalizar(x, -3.0), SR)
        print(f"{nome}.wav  {len(x) / SR:.2f} s")


if __name__ == "__main__":
    main()
