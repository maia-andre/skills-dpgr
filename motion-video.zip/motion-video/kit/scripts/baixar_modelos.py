"""Baixa pesos de TTS para modelos/. Só usa GitHub releases (Hugging Face costuma estar bloqueado).

  python scripts/baixar_modelos.py piper-dii
  python scripts/baixar_modelos.py kokoro
  python scripts/baixar_modelos.py whisper     # ASR para a conferência de pronúncia
"""
from __future__ import annotations

import sys
import tarfile
import urllib.request
from pathlib import Path

MODELOS = Path(__file__).resolve().parents[1] / "modelos"

GITHUB = {
    "piper-dii": [("https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/"
                   "vits-piper-pt_BR-dii-high.tar.bz2", ".")],
    # conferência de pronúncia (Whisper small em ONNX, ~640 MB; troque por -base para ~210 MB)
    "whisper": [("https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
                 "sherpa-onnx-whisper-small.tar.bz2", ".")],
    "kokoro": [
        ("https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx", "kokoro"),
        ("https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin", "kokoro"),
    ],
}

INSTRUCOES: dict[str, str] = {}


def baixar(url: str, destino: Path):
    destino.mkdir(parents=True, exist_ok=True)
    arq = destino / url.rsplit("/", 1)[1]
    if arq.exists() or (arq.suffix == ".bz2" and (destino / arq.name.replace(".tar.bz2", "")).exists()):
        print(f"  já existe: {arq.name}")
        return
    print(f"  baixando {url}")
    urllib.request.urlretrieve(url, arq)
    if arq.name.endswith(".tar.bz2"):
        with tarfile.open(arq) as t:
            t.extractall(destino, filter="data")
        arq.unlink()


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    for nome in sys.argv[1:]:
        print(nome)
        if nome in GITHUB:
            for url, sub in GITHUB[nome]:
                baixar(url, MODELOS / sub)
        elif nome in INSTRUCOES:
            print(INSTRUCOES[nome])
        else:
            print(f"  desconhecido. Opções: {', '.join([*GITHUB, *INSTRUCOES])}")


if __name__ == "__main__":
    main()
