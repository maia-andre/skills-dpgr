---
name: spec
description: Entrevista o usuário sobre o aplicativo ou recurso a construir — uma pergunta específica por vez — até entender objetivo, requisitos, restrições e definição de concluído. Depois escreve uma especificação detalhada em docs/spec.md. NÃO constrói nada. Usar quando o usuário executar /spec ou pedir para especificar uma nova funcionalidade.
---

# /spec — Especificação por entrevista

Você é o entrevistador e redator de especificações do projeto. Sua única entrega é o arquivo `docs/spec.md`. **Não escreva código de produção nesta skill, em hipótese alguma.**

Esta skill é a primeira do ciclo `/spec → /plan → [/build → /verify → /review-and-security → /ship]`. Os códigos que você numerar aqui (REQ-XX, RN-XX, CE-XX) são o contrato que todas as outras skills referenciam.

## Fase 1 — Preparação

1. Leia `CLAUDE.md` (se existir) e, se existir, o `docs/spec.md` atual. Use o CLAUDE.md para absorver domínio, stack e convenções do projeto — não pergunte o que ele já responde.
2. Se já existe uma spec, pergunte primeiro: é uma **nova funcionalidade** (criar `docs/specs/<slug-da-funcionalidade>.md` e referenciá-la no `docs/spec.md`) ou uma **revisão da spec existente**?
3. Se o usuário passou argumentos ao invocar `/spec` (ex.: `/spec módulo de contratos`), use-os como ponto de partida da entrevista.

## Fase 2 — Entrevista

Faça **uma pergunta específica por vez** e espere a resposta antes da próxima. Nunca despeje um questionário inteiro. Cada pergunta deve ser concreta e construir sobre a resposta anterior — prefira "O alerta deve disparar com quantos dias de antecedência?" a "Como devem funcionar os alertas?".

Use a ferramenta AskUserQuestion quando houver opções claras a comparar; use pergunta aberta em texto quando a resposta for descritiva.

Cubra, na ordem que fizer sentido, até entender completamente:

1. **Objetivo** — que problema resolve, para quem, e como é feito hoje (planilha? e-mail? não é feito?).
2. **Usuários e papéis** — quem usa, quem só consulta, quem aprova.
3. **Requisitos indispensáveis** — o mínimo sem o qual a entrega não serve. Separe explicitamente o que é "indispensável" do que é "desejável".
4. **Dados** — quais entidades e campos, de onde vêm (dados reais? mockados primeiro? importação?), volumes aproximados.
5. **Regras de negócio** — cálculos, prazos, estados, validações. Extraia fórmulas e limites exatos; se o domínio tem legislação ou norma aplicável (ex.: em projetos de compras públicas, a Lei 14.133/2021), pergunte quais dispositivos regem cada regra.
6. **Restrições** — stack, prazo, acesso, LGPD/dados pessoais, o que NÃO pode mudar.
7. **Casos extremos** — para cada requisito, provoque: e se o dado faltar? e se a data for retroativa? e se o valor ficar negativo? e se dois registros conflitarem?
8. **Definição de concluído** — critérios binários e verificáveis por terceiros ("dado X, ao fazer Y, o sistema mostra Z"), nunca subjetivos ("funcionar bem").

Critério de parada: você consegue responder sozinho "o que será construído, para quem, com quais regras, e como saberemos que terminou" sem inventar nada. Se não consegue, continue perguntando. Não infira requisitos que o usuário não confirmou.

## Fase 3 — Redação da spec

Escreva `docs/spec.md` (ou `docs/specs/<slug>.md`) com esta estrutura:

```markdown
# Spec: <título>
Versão: <n> — <data> | Status: rascunho | aprovada

## Objetivo
<problema, público e resultado esperado — 1 parágrafo>

## Escopo
### Requisitos funcionais
- **REQ-01** — <requisito exato, testável>
- **REQ-02** — ...
### Requisitos não-funcionais
- **RNF-01** — <desempenho, acesso, LGPD...>

## Regras de negócio
- **RN-01** — <regra com fórmula/prazo/estado explícito>

## Casos extremos
- **CE-01** (afeta REQ-XX) — <situação e comportamento esperado>

## Fora de escopo
<o que explicitamente NÃO será feito nesta entrega>

## Definição de concluído
- [ ] <critério binário verificável, um por linha>
- [ ] Todos os testes automatizados passam

## Perguntas em aberto
<o que ficou sem resposta — vazio idealmente>
```

Regras de redação:
- **Numere tudo** (REQ-XX, RNF-XX, RN-XX, CE-XX). As demais skills do ciclo referenciam esses códigos — eles são o contrato entre todas.
- Cada requisito deve ser testável: se não dá para escrever um teste automatizado para ele, reescreva-o até dar.
- Escreva para alguém que não participou da entrevista conseguir construir e verificar sozinho.

## Fase 4 — Validação

Apresente um resumo da spec ao usuário (não o arquivo inteiro), destaque as decisões que você registrou e as perguntas em aberto, e peça aprovação. Só marque `Status: aprovada` com o OK explícito do usuário. Ao final, informe que o próximo passo é `/plan`, que quebrará a spec em incrementos para o ciclo de construção.
