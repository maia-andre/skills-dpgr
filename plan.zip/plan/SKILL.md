---
name: plan
description: Lê a spec aprovada (docs/spec.md) e a quebra em um backlog de incrementos pequenos, ordenados por dependência, em docs/plan.md — cada incremento com seus REQ/RN/CE e uma entrega verificável de ponta a ponta. É o motor do loop de construção; cada iteração do ciclo pega o próximo incremento pendente. NÃO constrói nada. Usar quando o usuário executar /plan ou pedir para planejar a implementação da spec.
---

# /plan — Backlog de incrementos a partir da spec

Você traduz a spec em um plano de construção incremental. Sua única entrega é `docs/plan.md`. **Não escreva código de produção nesta skill.**

O `docs/plan.md` é a máquina de estados do loop: `/build` pega o próximo incremento pendente e o marca `em construção`; `/ship` o marca `concluído`. Portanto o formato de status abaixo é contrato — não o altere.

## Fase 1 — Carregar o contrato

1. Leia a spec (`docs/spec.md` ou a passada como argumento, ex.: `/plan docs/specs/contratos.md`).
2. Se não existir spec, **pare** e oriente o usuário a rodar `/spec` primeiro.
3. Se a spec não estiver `Status: aprovada`, avise o usuário e peça confirmação antes de planejar sobre rascunho.
4. Se já existe `docs/plan.md` para esta spec, pergunte: **replanejar do zero** (só é seguro se nenhum incremento foi construído) ou **estender** (adicionar incrementos novos ao final, sem tocar nos concluídos)?
5. Leia o `CLAUDE.md` (se existir) e a estrutura atual do código para ordenar os incrementos conforme o que já existe.

## Fase 2 — Recorte em incrementos

Quebre a spec em incrementos que obedeçam a todas estas regras:

- **Pequeno**: construível e testável em uma iteração do ciclo (uma passada de `/build`). Se um incremento agrupa mais de ~3 REQs, provavelmente deve ser dividido.
- **Verificável de ponta a ponta**: ao final do incremento, existe algo que roda e pode ser demonstrado (uma tela que abre, um endpoint que responde, um comando que processa). "Criei as models" não é um incremento; "cadastro salva e lista registros" é.
- **Ordenado por dependência**: nenhum incremento depende de um posterior. O primeiro incremento deve deixar o esqueleto executável do projeto de pé (app sobe, suíte de testes roda, ainda que quase vazia).
- **Cobertura total**: cada REQ, RNF, RN e CE da spec aparece em **exatamente um** incremento. Ao final, confira a soma: item da spec fora do plano é plano incompleto; item repetido em dois incrementos é conflito de escopo.

## Fase 3 — Redação do plano

Ao gravar um plano novo (primeiro plano de uma spec ou replanejamento do zero), apague os relatórios de ciclos anteriores (`docs/build-report.md`, `docs/verify-report.md`, `docs/review-report.md`) — relatório órfão de outro ciclo desvia a Fase 1 do `/build`. No modo **estender**, mantenha-os.

Escreva `docs/plan.md`:

```markdown
# Plan: <título da spec>
Spec: <caminho e versão> | Gerado: <data>
Progresso: 0/<N> incrementos concluídos

## Backlog

### INC-01 — <nome curto do incremento>
Status: pendente
Itens da spec: REQ-01, REQ-02 | RNF-01 | RN-01 | CE-01, CE-02
Depende de: —
Entrega verificável: <o que dá para demonstrar rodando ao final — 1 frase concreta>

### INC-02 — <nome>
Status: pendente
Itens da spec: ...
Depende de: INC-01
Entrega verificável: ...

## Cobertura
<confirmação de que todo item da spec está em exatamente um incremento; liste exceções se houver>
```

Valores possíveis de `Status`: `pendente` | `em construção` | `em correção` | `concluído`. Todo incremento nasce `pendente`.

## Fase 4 — Validação

Apresente ao usuário um resumo: quantos incrementos, a ordem, e o que cada um entrega de demonstrável. Ajuste conforme o feedback e peça aprovação.

Com o plano aprovado, informe os dois caminhos:
- **Manual**: rodar `/build` para construir o INC-01.
- **Loop autônomo**: rodar `/loop` com o prompt do ciclo, por exemplo:
  `/loop leia docs/plan.md; se houver incremento "em correção" ou "em construção", retome-o; senão pegue o próximo "pendente" com dependências concluídas; rode /build, depois /verify; se o verify encontrar FALHA, volte ao /build (correção) e repita o verify; senão rode /review-and-security; se REPROVADO, rode /build (correção), /verify e /review-and-security de novo; se APROVADO, rode /ship e siga ao próximo incremento; se o MESMO incremento for REPROVADO 3 vezes seguidas, pare o loop e me avise em vez de insistir; quando não restar incremento pendente, encerre o loop`
