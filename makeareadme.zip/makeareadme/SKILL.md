---
name: makeareadme
description: Diretrizes para escrever ou revisar o README de um projeto com cara profissional, mais os arquivos de comunidade (CONTRIBUTING, código de conduta, SECURITY), selos e CI. Use ao criar, reescrever, enxugar ou revisar um README, ou quando o usuário pedir um README "profissional", "elegante" ou "para publicar".
---

# README profissional

Diretrizes tiradas de READMEs de projetos maduros (requests, FastAPI, GOV.UK Frontend, Querido Diário, Serenata de Amor) e dos guias do GitHub, do standard-readme e do makeareadme.com. Elas servem de ponto de partida, não de regra rígida. O que o usuário já decidiu num projeto vale mais do que esta lista.

## Antes de escrever

Leia o código, a documentação existente e o histórico. O README descreve o que o projeto **faz hoje**: nada de prometer o que não foi testado, e o planejado fica marcado como planejado.

Pergunte ao usuário só o que não dá para deduzir:
- o nome de exibição, se for diferente do nome do repositório;
- o contato público (e-mail institucional, só GitHub...). Nunca use um e-mail pessoal visto no ambiente sem perguntar;
- a licença, se ainda não existir;
- o público: desenvolvedores, usuários finais ou os dois.

## Abertura

1. **Título:** um nome que explique o que o projeto faz. Se for diferente do nome do repositório, ponha o nome do repositório logo abaixo, em itálico.
2. **Uma frase de descrição**, com menos de 120 caracteres, igual à descrição do repositório no GitHub. Atualize a descrição com `gh repo edit --description` se o usuário concordar.
3. **Selos:** de 3 a 5, e só os úteis:
   - CI (o selo nativo do GitHub Actions, que mostra o estado real dos testes);
   - versão (`img.shields.io/github/v/release/...`, que se atualiza sozinho);
   - licença;
   - linguagem e principais ferramentas da stack.

   Evite selos decorativos ou estáticos que envelhecem: "em construção", número fixo de testes, contagem de funcionalidades, plataforma, leis.
4. **Um ou dois parágrafos** sobre o problema e o que o projeto resolve. Explicar a dor do usuário vale mais do que seguir à risca a ordem padrão.

## Forma

- **Emojis:** no máximo um ou dois no documento todo, de preferência só no título. Nunca nos títulos de seção nem para indicar situação em tabelas. Situação vai em texto: "Disponível", "Adiada", "Concluído", "Próximo".
- **Tom:** sóbrio e instrutivo, como o GOV.UK. Frases diretas, sem marketing, sem superlativos.
- **Diagramas:** no máximo um, o que explica o conceito central. Prints de tela são melhores, mas só quando a interface estiver estável.
- **Sumário manual:** dispensável. O GitHub já gera o índice das seções (ícone de lista no canto da página).
- **Blocos recolhíveis** (`<details>`) para detalhes longos que poucos leitores precisam.
- **Avisos do GitHub** (`> [!NOTE]`, `> [!TIP]`, `> [!WARNING]`) com moderação, para o que o leitor não pode perder.
- **Links relativos** para arquivos do repositório (`docs/spec.md`, `LICENSE`). Links absolutos quebram em forks e clones.
- **Âncoras:** sem emoji nos títulos, a âncora é previsível (`#como-rodar`). Confira as âncoras citadas em outros arquivos, como o CONTRIBUTING.

## Ordem sugerida

Ajuste ao projeto. Em geral:

1. Título, nome do repositório, descrição e selos
2. O problema e o que o projeto resolve
3. Princípios ou garantias, se o projeto tiver (privacidade, o que ele nunca faz)
4. O que o projeto faz hoje (funcionalidades, com situação em texto)
5. Como funciona (o conceito central, com o único diagrama)
6. Instalação e uso, com blocos de código copiáveis
7. Versões e roadmap, com link para Releases e Milestones
8. Como contribuir: resumo e link para o CONTRIBUTING
9. Documentação: links para o que está em `docs/`
10. Mantenedor, com contato
11. Aviso ou limitações, se houver
12. Licença, sempre por último, com o titular do copyright e o link para LICENSE

## Tamanho

O README é a porta de entrada, não a documentação inteira. Referências: GOV.UK, cerca de 900 palavras; requests, cerca de 400. Num projeto ainda imaturo, tabelas maiores podem ficar no README. Quando o projeto amadurecer, proponha mover os detalhes para `docs/` e deixar só um link.

## Arquivos de comunidade

Para projeto aberto a colaboração, confira a aba "Community Standards" do GitHub (Insights > Community):

- **CONTRIBUTING.md:**
  - formas de contribuir, sem e com código;
  - como preparar o ambiente e rodar os testes;
  - regras do projeto e padrão de commits;
  - aviso de que as contribuições seguem a licença do projeto;
  - contato.
- **CODE_OF_CONDUCT.md:** Contributor Covenant 2.1, de preferência na língua do projeto. A tradução oficial pt-BR está em `EthicalSource/contributor_covenant`, branch `release`, arquivo `content/version/2/1/code_of_conduct.pt-br.md`. Tire o front matter e troque `[INSERIR MÉTODO DE CONTATO]` pelo contato real.
- **SECURITY.md:**
  - versões atendidas;
  - como relatar sem issue pública, pelo canal privado do GitHub (ative com `gh api -X PUT repos/<dono>/<repo>/private-vulnerability-reporting`) e um e-mail;
  - prazo realista de resposta;
  - o que interessa relatar e o que está fora do escopo.
- **Formulários de issue** (`.github/ISSUE_TEMPLATE/*.yml`) quando houver contribuições recorrentes com o mesmo formato.
- **LICENSE** com o texto oficial (por exemplo, `gh api licenses/agpl-3.0 --jq .body`), nunca reescrito à mão.

## CI e selo de testes

Se o projeto tem testes, crie um fluxo simples em `.github/workflows/` que rode a suíte a cada push e pull request, na plataforma principal do projeto, com `permissions: contents: read`. Use o selo nativo (`.../actions/workflows/<arquivo>.yml/badge.svg`) no lugar de um selo estático com o número de testes. Depois do primeiro push, acompanhe a execução (`gh run watch`) e só anuncie o selo verde depois de ver o resultado.

## Antes de entregar

- [ ] Nenhuma afirmação além do que o projeto faz hoje; o planejado está marcado como tal.
- [ ] Nenhum dado pessoal, senha, caminho interno de rede ou ressalva interna irrelevante para o público.
- [ ] Links e âncoras funcionam, inclusive os citados em CONTRIBUTING e SECURITY.
- [ ] Selos apontam para recursos que existem (workflow, releases, LICENSE).
- [ ] Nome, descrição do repositório e título da aplicação são iguais.
- [ ] Emojis: no máximo dois.

## Fontes

- GitHub Docs, "About READMEs": https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes
- standard-readme: https://github.com/RichardLitt/standard-readme/blob/main/spec.md
- Make a README: https://www.makeareadme.com/
- Exemplos: alphagov/govuk-frontend, okfn-brasil/querido-diario, okfn-brasil/serenata-de-amor, psf/requests, fastapi/fastapi
